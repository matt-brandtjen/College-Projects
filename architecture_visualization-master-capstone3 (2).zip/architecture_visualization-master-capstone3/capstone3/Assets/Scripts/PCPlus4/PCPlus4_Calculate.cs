using UnityEngine;

public class PCPlus4_Calculate : MonoBehaviour
{
    public GameObject InputWire;
    
    private bool done = false;
    
    public void calculate() {
        if(InputWire.transform.GetChild(0).GetComponent<W32_SphereController>().isdone())
            done = true;
    }
    
    public bool isdone() {
        return done;
    }
    
    public void reset() {
        this.done = false;
    }
}
