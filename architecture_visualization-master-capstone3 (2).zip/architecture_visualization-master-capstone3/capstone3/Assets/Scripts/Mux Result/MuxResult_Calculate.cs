using UnityEngine;

public class MuxResult_Calculate : MonoBehaviour {
    public GameObject W47;
    public GameObject W50;
    
    private bool done = false;
    
    public void calculate(){
        if(W47.transform.GetChild(0).GetComponent<W47_SphereController>().isdone() ||
           W50.transform.GetChild(0).GetComponent<W50_SphereController>().isdone()){

            done = true;
        }
    }
    
    public bool isdone() {
        return this.done;
    }
    
    public void reset() {
        this.done = false;
    }
}
