using UnityEngine;

public class PC_Calculate : MonoBehaviour {
    public GameObject W29;
    private bool done = false;
    
    public void calculate() {
        if(W29.transform.GetChild(0).GetComponent<W29_SphereController>().isdone())
            done = true;
    }
    
    public bool isdone() {
        return this.done;
    }
    
    public void reset() {
        this.done = false;
    }
}

