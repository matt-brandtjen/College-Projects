using UnityEngine;

public class PCPlus8_Calculate : MonoBehaviour
{
    public GameObject Wire11;
    private bool done = false;
    
    public void calculate() {
        if (Wire11.GetComponent<W11_SphereController>().isdone())
            done = true;
    }
    
    public bool isdone() {
        return done;
    }
}
