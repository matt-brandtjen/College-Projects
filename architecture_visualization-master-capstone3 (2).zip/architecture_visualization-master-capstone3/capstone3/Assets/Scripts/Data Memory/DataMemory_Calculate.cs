using System.Collections.Generic;
using UnityEngine;

public class DataMemory_Calculate : MonoBehaviour {
    public GameObject W44;
    public GameObject W43;
    
    private bool done = false;
    private Dictionary<string,string> D_mem = new Dictionary<string,string>();

    private List<string> setAddresses = new List<string>();
    
    void Start() {
        System.Random random = new System.Random();
    }

    public void calculate() {
        if((W44.transform.GetChild(0).GetComponent<W44_SphereController>().isdone() &&
           W43.transform.GetChild(0).GetComponent<W43_SphereController>().isdone())
           ||
           (W43.transform.GetChild(0).GetComponent<W43_SphereController>().isdone() &&
           GameObject.Find("CLK").GetComponent<Run>().get_currentOperation().get_Name().Contains("ldr"))){

            done = true;
        }
    }

    public string print_data() {
        string a = "";
        string b = "";

        foreach (KeyValuePair<string, string> kvp in D_mem) {
            if (setAddresses.Contains(kvp.Key) ) {
                a = kvp.Key + " : " + kvp.Value + "\n";
                b += a;
            }
        }

        return b;
    }

    // Used for Data Memory Set button.
    // Only accepts integer values.
    public void set_mem_util(string mem, string value) {
        int mem_int = System.Convert.ToInt32(mem);
        int value_int = System.Convert.ToInt32(value);

        string value_inhex = value_int.ToString("X");
        string val_in_add = "0x";
        for (int i = 0; i < (8 - value_inhex.Length); i++) {
            val_in_add += "0";
        }
        val_in_add += value_inhex;

        string mem_inhex = mem_int.ToString("X");
        string mem_add = "0x";
        for (int i = 0; i < (8 - mem_inhex.Length); i++) {
            mem_add += "0";
        }
        mem_add += mem_inhex;

        set_mem(mem_add, val_in_add);
    }
    
    public void set_mem(string addr, string data) {
        D_mem[addr] = data;
        setAddresses.Add(data);
    }
    
    public string get_mem(string mem) {
        return D_mem[mem];
    }
    
    public bool isdone(){
        return this.done;
    }
    
    public void reset(){
        this.done = false;
    }
}
