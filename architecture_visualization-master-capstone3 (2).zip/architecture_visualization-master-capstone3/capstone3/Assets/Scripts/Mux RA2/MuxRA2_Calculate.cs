using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MuxRA2_Calculate : MonoBehaviour {
    public GameObject W30;
    public GameObject W25;
    
    private bool done = false;
    
    public void calculate(){
        if(W30.GetComponent<SphereController30>().isdone() || W25.GetComponent<W25_SphereController>().isdone())
            done = true;
    }
    
    public bool isdone(){
        return this.done;
    }
    
    public void reset(){
        this.done = false;
    }
}
