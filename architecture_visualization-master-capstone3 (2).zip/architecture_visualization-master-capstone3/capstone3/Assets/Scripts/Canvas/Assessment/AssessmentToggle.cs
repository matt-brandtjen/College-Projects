using UnityEngine;
using UnityEngine.UI;

public class AssessmentToggle : MonoBehaviour {
    public bool is_active;

    public void OnClick() {
        if (is_active) {
            is_active = false;
            this.gameObject.GetComponent<Image>().color = Color.white;
        } else {
            is_active = true;
            this.gameObject.GetComponent<Image>().color = Color.yellow;
        }
    }
    void Start() {
        is_active = false;
        GetComponent<Image>().color = Color.white;
    }
}
