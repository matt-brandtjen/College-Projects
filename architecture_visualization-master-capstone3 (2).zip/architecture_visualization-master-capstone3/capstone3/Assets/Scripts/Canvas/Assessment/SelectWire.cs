using System.Collections.Generic;
using UnityEngine;

public class SelectWire : MonoBehaviour {
    public GameObject input;
    public Material selected_color;
    public Material original_color;
    public Material invalid_color;
    public List<GameObject> linked_wires;

    private void OnMouseDown() {
        bool assess_enabled = GameObject.Find("Assessment Toggle").GetComponent<AssessmentToggle>().is_active;
        if (!assess_enabled) 
            return;

        bool cur_active = input.activeInHierarchy;
        if (cur_active) {
            input.SetActive(false);
            this.gameObject.GetComponent<MeshRenderer>().material = original_color;
            foreach (GameObject wire in linked_wires) {
                wire.GetComponent<MeshRenderer>().material = original_color;
            }
        } else {
            input.SetActive(true);
            this.gameObject.GetComponent<MeshRenderer>().material = selected_color;
            foreach (GameObject wire in linked_wires) {
                wire.GetComponent<MeshRenderer>().material = selected_color;
            }
        }

    }

    void Start() {
        original_color = this.gameObject.GetComponent<MeshRenderer>().material;
    }

    public void changeColor(string color) {
        var material = original_color;
        switch (color) {
            case "red": { material = invalid_color; } break;
            case "yellow": { material = selected_color; } break;
        }

        this.gameObject.GetComponent<MeshRenderer>().material = material;

        foreach (GameObject wire in linked_wires) {
            wire.GetComponent<MeshRenderer>().material = material;
        }
    }
}
