using UnityEngine;
using UnityEngine.SceneManagement;

public class RestartScene : MonoBehaviour {
    public void restart_scene() {
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }
}
