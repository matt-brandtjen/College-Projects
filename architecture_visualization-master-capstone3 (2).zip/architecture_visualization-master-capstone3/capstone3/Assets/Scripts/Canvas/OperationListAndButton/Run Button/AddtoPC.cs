using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System;

public class AddtoPC : MonoBehaviour {
    public GameObject OperationContent;
    public GameObject registerfile;
    public GameObject I_Memory;
    public GameObject ErrorBox;
    public GameObject ErrorMessageBox;

    private RegisterFile regfile;

    private bool clicked = false;
    private bool firsttime = true;
    private bool error_found = false;
    private List<Instruction> F_operations;
    private List<string> used_R = new List<string>();
    private List<string> e_messages = new List<string>();

    private string imm = null;

    public List<Instruction> get_operations() {
        regfile = registerfile.GetComponent<RegisterFile>(); // script that holds register values 

        if (firsttime) {
            firsttime = false;
            int num_instructions = OperationContent.transform.childCount; // each child is operationContainer
            List<Instruction> operations = new List<Instruction>();

            for (int i = 0; i < num_instructions; i++) {
                string i_num = "Line" + (i + 1).ToString() + ": ";
                GameObject operationContainer = OperationContent.transform.GetChild(i).gameObject; // this is the instruction

                // get input values for instruction instantiation
                int operation_id = operationContainer.transform.GetChild(1).transform.GetComponent<Dropdown>().value; // add, sub, etc...
                string rd = operationContainer.transform.GetChild(2).transform.GetComponent<InputField>().text.ToUpper();
                string rs = operationContainer.transform.GetChild(3).transform.GetComponent<InputField>().text.ToUpper();
                string rt = operationContainer.transform.GetChild(4).transform.GetComponent<InputField>().text.ToUpper();

                if (operation_id != 0 && !rt.ToUpper().Contains("R")) 
                    imm = rt;

                else if (operation_id == 0 && !rs.ToUpper().Contains("R")) 
                    imm = rs;

                else 
                    imm = null;
                
                // validate input with utility operation_id
                bool input_is_valid = validateInput(operation_id, rd, rs, rt, ref i_num);
                error_found = !input_is_valid;
                
                string current_addr = operationContainer.transform.GetChild(6).transform.GetComponent<Text>().text;

                // instantiate instruction based off of value from dropdown (operation_id)
                if (input_is_valid) { 
                    operationContainer.GetComponent<Image>().enabled = false;

                    Instruction instr;
                    switch(operation_id) {
                        case 0:
                            instr = new Mov(rd, rs, rt, imm, operationContainer);
                            operations.Add(instr);
                            I_Memory.GetComponent<InstructionMemory_Calculate>().set_addr_operation(current_addr, instr);
                            break;
                        case 1:
                            instr = new Add(rd, rs, rt, imm, operationContainer);
                            operations.Add(new Add(rd, rs, rt, imm, operationContainer));
                            I_Memory.GetComponent<InstructionMemory_Calculate>().set_addr_operation(current_addr, instr);
                            break;
                        case 2:
                            instr = new Sub(rd, rs, rt, imm, operationContainer);
                            operations.Add(new Sub(rd, rs, rt, imm, operationContainer));
                            I_Memory.GetComponent<InstructionMemory_Calculate>().set_addr_operation(current_addr, instr);
                            break;
                        case 3:
                            instr = new Str(rd, rs, rt, imm, operationContainer);
                            operations.Add(new Str(rd, rs, rt, imm, operationContainer));
                            I_Memory.GetComponent<InstructionMemory_Calculate>().set_addr_operation(current_addr, instr);
                            break;
                        case 4:
                            instr = new Ldr(rd, rs, rt, imm, operationContainer);
                            operations.Add(new Ldr(rd, rs, rt, imm, operationContainer));
                            I_Memory.GetComponent<InstructionMemory_Calculate>().set_addr_operation(current_addr, instr);
                            break;
                        case 5:
                            instr = new Beq(rd, rs, rt, imm, operationContainer);
                            operations.Add(new Beq(rd, rs, rt, imm, operationContainer));
                            I_Memory.GetComponent<InstructionMemory_Calculate>().set_addr_operation(current_addr, instr);
                            break;
                    }

                    used_R.Add(rd.ToUpper());
                    
                }

                else {
                    operationContainer.GetComponent<Image>().enabled = true;
                    operationContainer.GetComponent<Image>().color = new Color32(188, 51, 40, 255);
                }
            }
            F_operations = operations;
            return operations;
        }

        else {
            firsttime = true;
            return F_operations;
        }
    }

    public void on_click() {
        List<Instruction> try_to_get = get_operations();
        if (!error_found) {
            for (int i = 0; i < OperationContent.transform.childCount; i++)
                OperationContent.transform.GetChild(i).GetComponent<Image>().enabled = false;
            
            clicked = true;
        }
        else {
            firsttime = true;
            string all_message = "";

            for (int i = 0; i < e_messages.Count; i++)
                all_message += e_messages[i] + Environment.NewLine;
            
            ErrorMessageBox.GetComponent<Text>().text = all_message;
            error_found = false;
            e_messages = new List<string>();
            used_R = new List<string>();
            F_operations = new List<Instruction>();
            ErrorBox.SetActive(true);
        }
    }

    public void set_click_f() {
        clicked = false;
    }

    public bool isclicked() {
        return clicked;
    }

    public bool noerror() {
        return !error_found;
    }

    private string tohex(string val) {
        if (!val.Contains("x")) {
            val = Convert.ToInt32(val).ToString("X");

            string h = "0x";
            for (int i = 0; i < 8 - val.Length; i++) {
                h += "0";
            }

            return h + val;
        }
        else {
            return val;
        }
    }

    public bool validateInput(int operation_id, string rd, string rs, string rt, ref string i_num) {
        if (operation_id != 0) {
            if (!rt.StartsWith("R")) {
                int out_imm;
                bool rt_casted_to_int = int.TryParse(rt, out out_imm);
                if (rt_casted_to_int) imm = out_imm.ToString();

                if (!rt_casted_to_int) {
                    e_messages.Add("rt field:  invalid input");
                    return false;
                }
            }

            if (rt.Length == 0) {
                e_messages.Add(i_num + "rt field:  cannot be empty");
                return false;
            } else {
                int tester;
                string newRt = rt;

                if (newRt.Contains("R"))
                    newRt = rt.Remove(0, 1);
                
                if (!int.TryParse(newRt, out tester) && !rt.Contains("x")) {
                    e_messages.Add(i_num + "rt field:  invalid input");
                    return false;
                }
            }
        }

        if (rd.Length == 0) {
            e_messages.Add(i_num + "rd field:  cannot be empty");
            return false;
        } else {
            int tester;

            // check if input is valid
            if (!int.TryParse(rd.Remove(0, 1), out tester) && !rd.Contains("x")) {
                e_messages.Add(i_num + "rd field:  invalid input");
                return false;
            }
        }
        
        int d_num = Convert.ToInt32(rd.Remove(0, 1));
        if ( (d_num < 0 || d_num > 15) ) {
            e_messages.Add(i_num + "Register number cannot be less than 0 or greater than 15");
            return false;
        }

        if (rs.Length == 0) {
            e_messages.Add(i_num + "rs field:  cannot be empty");
            return false;
        } else {
            int tester;
            // check if input is valid
            if (!rs.StartsWith("R") && !int.TryParse(rs, out tester) && !rt.Contains("x"))
            {
                e_messages.Add(i_num + "rs field:  invalid input");
                return false;
            }
        }

        int int_imm; 
        if (!regfile.ContainsR(rs) && !used_R.Contains(rs) && !int.TryParse(rs, out int_imm)) {
            e_messages.Add(i_num + "rs field:  invalid or undefined");
            return false;
        }
        
        return true;
    }
}
