using UnityEngine;
using UnityEngine.UI;

public class Image_Switch : MonoBehaviour {
    public Sprite StartIcon;
    public Sprite PauseIcon;
    
    private bool start = true;
    
    public void switchIcon() {
        start = !start;

        if (start) GetComponent<Image>().sprite = StartIcon;
        else GetComponent<Image>().sprite = PauseIcon;
    }
    
    public void set_Icon_play() {
        start = true;
        GetComponent<Image>().sprite = StartIcon;
    }
    
    
}
