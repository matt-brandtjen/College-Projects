using UnityEngine;

public class OperationListOpener : MonoBehaviour {
    public GameObject OperationList;
    
    void Start() {
        OperationList.SetActive(true);
    }

    public void OperationList_visible_Control(){
        bool isActive = OperationList.activeSelf;
        OperationList.SetActive(!isActive);
    }
}
