using UnityEngine;
using UnityEngine.UI;
using System;

public class RegisterManager : MonoBehaviour {
    public GameObject Rt;
    public GameObject label;
    public GameObject counter;

    public void value_change() {
         if(this.GetComponent<Dropdown>().value == 0){
            Rt.SetActive(false);
            label.SetActive(false);
         }
         else if (this.GetComponent<Dropdown>().value == 5)
         {
            string count =  counter.GetComponent<Text>().text.Replace(@".", "");
            int num = Int32.Parse(count);
            if (num == 1)
            {

            }
         	Rt.SetActive(false);
         	label.GetComponent<LabelManager>().update_Label();
         	label.SetActive(true);

         }
         else{
             Rt.SetActive(true);
             label.SetActive(false);
         }
    }
}


