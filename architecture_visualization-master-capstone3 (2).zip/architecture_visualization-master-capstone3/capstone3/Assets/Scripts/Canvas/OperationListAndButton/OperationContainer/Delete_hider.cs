using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Delete_hider : MonoBehaviour {
    public GameObject delete;

    void Start() {
        delete.SetActive(false);
    }
}
