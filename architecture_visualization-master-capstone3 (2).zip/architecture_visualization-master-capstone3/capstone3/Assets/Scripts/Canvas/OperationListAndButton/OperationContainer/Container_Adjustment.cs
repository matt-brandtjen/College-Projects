using UnityEngine;
using UnityEngine.UI;

public class Container_Adjustment : MonoBehaviour {
    public GameObject content;
    
    public void adjust() {
        int num_Child = content.transform.childCount;
        
        // Set the last adder to true
        content.transform.GetChild(num_Child - 1).transform.GetChild(8).gameObject.SetActive(true);
        
        for(int i = 0; i < num_Child; i++) {
            Transform container = content.transform.GetChild(i);
            // Set counters
            container.transform.GetChild(0).GetComponent<Text>().text = (i+1).ToString() + ".";
            
            // Set Labels
            if(container.transform.GetChild(1).GetComponent<Dropdown>().value == 4){
                container.transform.GetChild(5).GetComponent<LabelManager>().update_Label();
                container.transform.GetChild(5).transform.GetChild(0).GetComponent<Text>().text = container.transform.GetChild(5).GetComponent<Dropdown>().options[container.transform.GetChild(5).GetComponent<Dropdown>().value].text;
            }
        } 
    }
}
