using System;
using UnityEngine;
using UnityEngine.UI;

public class OperationAdder : MonoBehaviour {
    public GameObject containerTemplate;
    public GameObject thisButton;
    
    public void add_a_operation_to_list() {
        GameObject container = Instantiate(containerTemplate) as GameObject;
        container.SetActive(true);
        
        container.GetComponent<Image>().enabled = false;
        string current_num = container.transform.GetChild(0).transform.GetComponent<Text>().text;
        string current_addr = container.transform.GetChild(6).transform.GetComponent<Text>().text;
        int instruction_num = Convert.ToInt32(current_num.Remove(current_num.Length -1 ,1));
        
        int address = Convert.ToInt32(current_addr.Replace("0x",""), 16);
        int new_addr = address+4;

        container.transform.GetChild(0).transform.GetComponent<Text>().text = (instruction_num + 1).ToString() + ".";
        container.transform.GetChild(1).transform.GetComponent<Dropdown>().value = 0;
        container.transform.GetChild(2).transform.GetComponent<InputField>().text = "";
        container.transform.GetChild(3).transform.GetComponent<InputField>().text = "";
        container.transform.GetChild(4).transform.GetComponent<InputField>().text = "";
        container.transform.GetChild(6).transform.GetComponent<Text>().text = "0x" + new_addr.ToString("X4");
        container.transform.GetChild(4).gameObject.SetActive(false);
        
        if(this.transform.parent.transform.childCount > 0) 
            container.transform.GetChild(7).gameObject.SetActive(true);
        
        container.transform.SetParent(containerTemplate.transform.parent,false);
        thisButton.SetActive(false);
    }
}
