using UnityEngine;

public class OperationSelector : MonoBehaviour {
    public GameObject containerTemplate;
    
    public void select(int choice) {
        GameObject container = Instantiate(containerTemplate) as GameObject;
        container.SetActive(true);
        container.transform.SetParent(containerTemplate.transform.parent,false);
    }
}
