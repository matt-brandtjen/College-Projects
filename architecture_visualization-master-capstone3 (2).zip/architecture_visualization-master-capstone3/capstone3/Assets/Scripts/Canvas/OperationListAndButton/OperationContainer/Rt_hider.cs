using UnityEngine;

public class Rt_hider : MonoBehaviour {
    public GameObject Rt;

    void Start() {
        Rt.SetActive(false);
    }
}
