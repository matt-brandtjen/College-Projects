using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System;

public class LabelManager : MonoBehaviour {
    public GameObject counter;
    public Dropdown dropDownLabel;
    public GameObject content;
    
    List<string> temoNames;
    int num;

    public void update_Label() {
    	dropDownLabel = this.GetComponent<Dropdown>();
        temoNames = new List<string>(); 
        AddNames();
        UpdateDropDownItem(temoNames);
    }

    private void UpdateDropDownItem(List<string> showNames) {
        dropDownLabel.options.Clear();
        Dropdown.OptionData temoData;
        for (int i = 0; i <showNames.Count; i++) {
            temoData = new Dropdown.OptionData();
            temoData.text = showNames[i];
            dropDownLabel.options.Add(temoData);
        }
      
        if (num > 1)
            dropDownLabel.captionText.text = showNames[0];
    }

    private void AddNames() {
        num = content.transform.childCount;
        
        if(num > 1){
            for (int i = 0; i < num ; i++) {
                if(Convert.ToInt32(this.transform.parent.transform.GetChild(0).gameObject.GetComponent<Text>().text.Replace(".","")) != (i+1)){
                    temoNames.Add((i+1).ToString());
                }
            }
        } else temoNames.Add("N/A");
    }
}
