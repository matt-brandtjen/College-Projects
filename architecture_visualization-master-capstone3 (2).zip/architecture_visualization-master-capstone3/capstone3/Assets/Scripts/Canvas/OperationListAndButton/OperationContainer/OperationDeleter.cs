using UnityEngine;

public class OperationDeleter : MonoBehaviour {
    public GameObject container;
    
    public void delete_container(){
        container.transform.SetParent(null);
        Destroy(container);
    }
}
