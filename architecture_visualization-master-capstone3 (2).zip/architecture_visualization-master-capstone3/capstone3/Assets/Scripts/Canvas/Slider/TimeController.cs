using UnityEngine;
using UnityEngine.UI;

public class TimeController : MonoBehaviour
{
    public GameObject CLK;
    public GameObject R_Button;
    
    // Start is called before the first frame update
    void Start() {
        this.GetComponent<Slider>().value = 1;
    }

    public void time_controll(float factor){
        if(R_Button.GetComponent<AddtoPC>().isclicked())
            CLK.GetComponent<Run>().get_currentOperation().time_setter(factor);
    }
}
