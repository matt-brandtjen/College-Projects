using UnityEngine;

public class ErrorBox_Closer : MonoBehaviour {
    public GameObject errorbox;

    void Start() {
        errorbox.SetActive(false);
    }
}
