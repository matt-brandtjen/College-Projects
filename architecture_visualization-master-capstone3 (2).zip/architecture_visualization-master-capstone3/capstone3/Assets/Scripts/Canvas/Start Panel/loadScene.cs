using UnityEngine;
using UnityEngine.SceneManagement;

public class loadScene : MonoBehaviour {
    public void loadS(){
        SceneManager.LoadScene("CPU Model");
    }
}
