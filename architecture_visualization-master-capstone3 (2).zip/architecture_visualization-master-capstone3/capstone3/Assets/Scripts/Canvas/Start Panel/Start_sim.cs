using UnityEngine;
using UnityEngine.SceneManagement;

public class Start_sim : MonoBehaviour {
    public void close_panel() {
        SceneManager.LoadScene("CPU Model");
    }
}
