using UnityEngine;

public class Image_Mover : MonoBehaviour {
    public GameObject first;
    public GameObject second;
    
    private float speed = 15f;
    private Vector3 firstpos;
    private Vector3 secondpos;
    
    private float firstwid;
    private float secondwid;
    private float endpoint;
    
    void Start() {
        firstpos = first.transform.position;
        secondpos = second.transform.position;
        
        firstwid = first.GetComponent<RectTransform>().sizeDelta[0];
        speed *= Time.deltaTime;
        
        endpoint = firstpos[0] + firstwid;
    }

    void Update() {
        first.transform.Translate(speed,0f,0f);
        second.transform.Translate(speed,0f,0f);
        
        if(first.transform.position[0] >= (endpoint/100) - 10)
            first.transform.position = secondpos;

        if (second.transform.position[0] >= (endpoint / 100) - 10)
            second.transform.position = secondpos;
    }
}
