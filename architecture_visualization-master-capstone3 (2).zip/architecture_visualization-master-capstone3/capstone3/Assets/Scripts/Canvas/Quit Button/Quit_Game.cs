using UnityEngine;

public class Quit_Game : MonoBehaviour {
    public void quit_game(){
        Application.Quit();
    }
}
