using UnityEngine;

public class MuxRA1_Calculate : MonoBehaviour {
    public GameObject W1916;
    
    private bool done = false;
    
    public void calculate(){
        if(W1916.GetComponent<SphereController1916>().isdone())
            done = true;
    }
    
    public bool isdone(){
        return this.done;
    }
    
    public void reset(){
        this.done = false;
    }
}
