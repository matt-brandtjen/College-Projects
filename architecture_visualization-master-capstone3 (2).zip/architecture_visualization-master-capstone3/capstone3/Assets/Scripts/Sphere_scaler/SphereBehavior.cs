using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SphereBehavior : MonoBehaviour
{
    float radius = 2f;
    
    // Start is called before the first frame update
    void Start()
    {
        Vector3 locscale = transform.localScale;
        Vector3 gloscale = transform.lossyScale;
        
        transform.localScale = new Vector3(radius*(locscale.x/gloscale.x), radius*(locscale.y/gloscale.y),radius*(locscale.z/gloscale.z));
    }
    
}
