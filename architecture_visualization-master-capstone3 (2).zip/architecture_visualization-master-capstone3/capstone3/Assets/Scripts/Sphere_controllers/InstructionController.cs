using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class InstructionController : MonoBehaviour
{
	public Dropdown operations;
	
	public GameObject pc;
	public bool start = false;
	
	public Button button;
	public InputField firstInput;
	public InputField secondInput;
	public InputField thirdInput;
	
	private void Start()
	{
		operations.onValueChanged.AddListener(delegate
			{
				operationChanged(operations);
			});

		button.onClick.AddListener(GetInputOnClick);
	}
	
	public void operationChanged(Dropdown selected)
	{
        /*
		Debug.Log("You selected " + selected.value);
		
		Debug.Log("You selected " + selected.options[selected.value].text);
         */
	}
	
	public void GetInputOnClick()
	{
        /*
		Debug.Log("First input: " + firstInput.text);
		Debug.Log("Second input: " + secondInput.text);
		Debug.Log("Third input: " + thirdInput.text);
         */
	}
	
	public bool pc_started()
	{
		return this.start;
	}
	
	public void setStart()
	{
		start = true;
	}
}
