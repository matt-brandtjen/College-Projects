using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class W30_SphereController : MonoBehaviour
{
    public GameObject inputObject;
    public GameObject Sphere;
    public GameObject w28B;
    public GameObject w37B;
    public GameObject canvas;
    
    private Renderer rend;
    private bool done = false;
    private Instruction currentOperation;
    private bool first_move = true;
    private bool w28B_start = false;
    private bool w37B_start = false;
    // Start is called before the first frame update
    void Start()
    {
        rend = Sphere.GetComponent<Renderer>();
        canvas.SetActive(false);
    }

    // Sphere movement
    public void animate()
    {

        if (inputObject.GetComponent<W51_SphereController>().w30B_begin() && !done && Sphere.transform.localPosition.y < 1)
        {

            if (first_move)
            {
                currentOperation = GameObject.Find("CLK").GetComponent<Run>().get_currentOperation();

                rend.enabled = true;
                first_move = false;
                canvas.SetActive(true);
            }

            Sphere.transform.Translate(new Vector3(0f, 20f, 0f) * Time.deltaTime, Sphere.transform.parent);
        }
        else if (Sphere.transform.localPosition.y >= 1)
        {
            rend.enabled = false;
            done = true;
            canvas.SetActive(false);
        }
        check28();
        check37();
    }


    private void check28()
    {
        float Sphx = this.Sphere.transform.position.x;
     
        if (Sphx <= w28B.transform.position.x)
        {  
            w28B_start = true;
            canvas.SetActive(false);
        }
    }

    private void check37()
    {
        float Sphx = this.Sphere.transform.position.x;
        

        if (Sphx <= w37B.transform.position.x)
        {
            w37B_start = true;
            
            
            if(currentOperation.get_Name().Contains("sub") || currentOperation.get_Name().Contains("add") || currentOperation.get_Name().Contains("ldr") 
                || currentOperation.get_Name().Contains("mov")) {

                rend.enabled = false;
                canvas.SetActive(false);
                done = true;
                rend.enabled = false;
            }
        }
    }

    public bool w28B_begin()
    {
        return this.w28B_start;
    }

    public bool w37B_begin()
    {
        return this.w37B_start;
    }

    public bool isdone()
    {
        return this.done;
    }

    public void reset()
    {
        rend.enabled = false;
        done = false;
        first_move = true;
        w28B_start = false;
        w37B_start = false;
        canvas.SetActive(false);
        Sphere.transform.localPosition = new Vector3(0f, -1f, 0f);
        
    }
}
