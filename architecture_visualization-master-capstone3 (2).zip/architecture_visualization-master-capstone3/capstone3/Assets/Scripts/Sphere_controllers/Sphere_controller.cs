using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Sphere_controller : MonoBehaviour
{
    public GameObject Sphere;
    public Renderer rend;
    // Start is called before the first frame update
    void Start()
    {
        rend = Sphere.GetComponent<Renderer>();
        rend.enabled = false;
        

    }

    // Update is called once per frame
    void Update()
    {

        if (Sphere.transform.localPosition.y < 1)
	    {
            rend.enabled = true;
            this.transform.Translate ( new Vector3 (0f, 2f, 0f) * Time.deltaTime, Sphere.transform.parent);
	    }
        else
        {
            rend.enabled = false;
        }
    }
}
