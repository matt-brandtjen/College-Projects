using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class W70_SphereController : MonoBehaviour
{
    public GameObject inputObject;
    public GameObject Sphere;
    public GameObject w67B;
    private Renderer rend;
    private bool done = false;
    private bool first_move = true;
    private bool w67B_start = false;
    // Start is called before the first frame update
    void Start()
    {
        rend = Sphere.GetComponent<Renderer>();
    }

    // Sphere movement
    void animate()
    {

        if (inputObject.GetComponent<W69_SphereController>().w70B_begin() && !done && Sphere.transform.localPosition.y < 1)
        {

            if (first_move)
            {
                rend.enabled = true;
                first_move = false;
            }

            Sphere.transform.Translate(new Vector3(0f, 4f, 0f) * Time.deltaTime, Sphere.transform.parent);
        }
        else if (Sphere.transform.localPosition.y >= 1)
        {
            rend.enabled = false;
            done = true;
        }
    }


    private void check()
    {
        float Sphz = this.Sphere.transform.position.z;

        if (Sphz <= w67B.transform.position.z)
        {

            w67B_start = true;
        }
    }

    public bool w67B_begin()
    {
        return this.w67B_start;
    }

    public bool isdone()
    {
        return this.done;
    }

    void reset()
    {
        done = false;
        first_move = true;
        Sphere.transform.localPosition = new Vector3(0f, -1f, 0f);
    }
}
