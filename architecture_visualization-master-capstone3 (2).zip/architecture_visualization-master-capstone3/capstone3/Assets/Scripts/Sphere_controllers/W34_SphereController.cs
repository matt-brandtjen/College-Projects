using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class W34_SphereController : MonoBehaviour
{
    public GameObject inputObject;
    public GameObject Sphere;
    public GameObject w33B;
    public GameObject canvas;
    private Renderer rend;
    private bool done = false;
    private bool first_move = true;
    private bool w33B_start = false;
    // Start is called before the first frame update
    void Start()
    {
        rend = Sphere.GetComponent<Renderer>();
        canvas.SetActive(false);
    }

    // Sphere movement
    public void animate()
    {

        if (inputObject.GetComponent<W35_SphereController>().w34B_begin() && !done && Sphere.transform.localPosition.y < 1)
        {

            if (first_move)
            {
                rend.enabled = true;
                first_move = false;
                canvas.SetActive(true);
            }

            Sphere.transform.Translate(new Vector3(0f, 5f, 0f) * Time.deltaTime, Sphere.transform.parent);
        }
        else if (Sphere.transform.localPosition.y >= 1)
        {
            rend.enabled = false;
            done = true;
            canvas.SetActive(false);
        }
        check();
    }


    private void check()
    {
        float Sphx = this.Sphere.transform.position.x;

        if (Sphx <= w33B.transform.position.x)
        {

            w33B_start = true;
        }
    }

    public bool w33B_begin()
    {
        return this.w33B_start;
    }

    public bool isdone()
    {
        return this.done;
    }

    public void reset()
    {
        done = false;
        w33B_start = false;
        first_move = true;
        Sphere.transform.localPosition = new Vector3(0f, -1f, 0f);
        canvas.SetActive(false);
    }
}
