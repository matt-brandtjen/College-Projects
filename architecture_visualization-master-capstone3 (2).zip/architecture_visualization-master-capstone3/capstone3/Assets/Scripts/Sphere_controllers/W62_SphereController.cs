using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class W62_SphereController : MonoBehaviour
{
    public GameObject ALUControl;
    public GameObject Sphere;
    public GameObject canvas;
    private Renderer rend;
    private bool done = false;
    private bool first_move = true;
    
    // Start is called before the first frame update
    public void Start()
    {
        rend = Sphere.GetComponent<Renderer>();
        rend.enabled = false;
        canvas.SetActive(false);
    }
    
    // Sphere movement
    public void animate(){
        
        if(ALUControl.GetComponent<ALUControl_SphereController>().isdone() && Sphere.transform.localPosition.y < 1 && !done){
            
            if(first_move){
                rend.enabled = true;
                first_move = false;
                canvas.SetActive(true);
            }
             
            Sphere.transform.Translate(new Vector3(0f,0f,16f)*Time.deltaTime);
        }
        else if(Sphere.transform.localPosition.y >= 1){
            rend.enabled = false;
            canvas.SetActive(false);
            done = true;
        }
    }
    
    public bool isdone(){
        return this.done;
    }
    
    public void reset(){
        done = false;
        first_move = true;
        canvas.SetActive(false);
        Sphere.transform.localPosition = new Vector3(0f,-1f,0f);
    }

}
