using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class W43_SphereController : MonoBehaviour
{
    public GameObject ALU;
    public GameObject inputObject;
    public GameObject Sphere;
    public GameObject w46;
    public GameObject canvas;
    
    private Instruction currentOperation;
    private Renderer rend;
    private bool done = false;
    private bool first_move = true;
	private bool w46_start = false;
    // Start is called before the first frame update
    void Start()
    {
        rend = Sphere.GetComponent<Renderer>();
        canvas.SetActive(false);
    }

    // Sphere movement
    public void animate()
    {
        if(ALU.GetComponent<ALU_Calculate>().isdone()){
            if (!done && Sphere.transform.localPosition.y < 1)
            {

                if (first_move)
                {
                    rend.enabled = true;
                    first_move = false;
                    canvas.SetActive(true);
                    currentOperation = GameObject.Find("CLK").GetComponent<Run>().get_currentOperation();
                }

                Sphere.transform.Translate(new Vector3(0f, 8f, 0f) * Time.deltaTime, Sphere.transform.parent);
            }
            else if (Sphere.transform.localPosition.y >= 1)
            {
                rend.enabled = false;
                done = true;
                canvas.SetActive(false);
            }
            checkw46();
        }
    }

    private void checkw46()
    {
        float Sphx = this.Sphere.transform.position.x;
     
        if (Sphx >= w46.transform.position.x)
        {
            w46_start = true;
            canvas.SetActive(false);
            
            if(currentOperation.get_Name().Contains("sub") || currentOperation.get_Name().Contains("add") || currentOperation.get_Name().Contains("beq")
                || currentOperation.get_Name().Contains("mov")){

                rend.enabled = false;
                done = true;
                rend.enabled = false;
            }
        }
    }

    public bool w46_begin()
    {
        return this.w46_start;
    }

    public bool isdone()
    {
        return this.done;
    }

    public void reset()
    {
        done = false;
        first_move = true;
        w46_start = false;
        Sphere.transform.localPosition = new Vector3(0f, -1f, 0f);
        canvas.SetActive(false);
    }
}
