using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class W11_SphereController : MonoBehaviour
{
    public GameObject Sphere;
    public GameObject w35B;
    public GameObject PCPlus4;
    public GameObject canvas;
    private Renderer rend;
    private bool done = false;
    private bool first_move = true;
    private bool w35B_start = false;
    // Start is called before the first frame update
    void Start()
    {
        rend = Sphere.GetComponent<Renderer>();
        canvas.SetActive(false);
    }

    // Sphere movement
    public void animate()
    {
        if(PCPlus4.GetComponent<PCPlus4_Calculate>().isdone()){
            if (!done && Sphere.transform.localPosition.y < 1)
            {

                if (first_move)
                {
                    rend.enabled = true;
                    first_move = false;
                    canvas.SetActive(true);
                }

                Sphere.transform.Translate(new Vector3(0f, 5f, 0f) * Time.deltaTime, Sphere.transform.parent);
            }
            else if (Sphere.transform.localPosition.y >= 1)
            {
                rend.enabled = false;
                done = true;
                canvas.SetActive(false);
            }
            check();
        }
    }


    private void check()
    {
        float Sphx = this.Sphere.transform.position.x;

        if (Sphx >= w35B.transform.position.x)
        {

            w35B_start = true;
        }
    }

    public bool w35B_begin()
    {
        return this.w35B_start;
    }

    public bool isdone()
    {
        return this.done;
    }

    public void reset()
    {
        done = false;
        w35B_start = false;
        first_move = true;
        Sphere.transform.localPosition = new Vector3(0f, -1f, 0f);
        canvas.SetActive(false);
    }
}
