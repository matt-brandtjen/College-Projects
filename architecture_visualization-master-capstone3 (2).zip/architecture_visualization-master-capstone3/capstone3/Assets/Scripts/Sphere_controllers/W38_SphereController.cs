using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class W38_SphereController : MonoBehaviour
{
    public GameObject RegisterFile;
    public GameObject inputObject;
    public GameObject Sphere;
    public GameObject w45;
    public GameObject canvas;
    private Renderer rend;
    private bool done = false;
    private bool first_move = true;
    private bool w45_start = false;
    // Start is called before the first frame update
    void Start()
    {
        rend = Sphere.GetComponent<Renderer>();
        canvas.SetActive(false);
    }

    // Sphere movement
    public void animate()
    {
        if(RegisterFile.GetComponent<RegisterFile>().isdone()){
            if (!done && Sphere.transform.localPosition.y < 1)
            {

                if (first_move)
                {
                    rend.enabled = true;
                    first_move = false;
                    canvas.SetActive(true);
                }

                Sphere.transform.Translate(new Vector3(0f, 8f, 0f) * Time.deltaTime, Sphere.transform.parent);
            }
            else if (Sphere.transform.localPosition.y >= 1)
            {
                rend.enabled = false;
                done = true;
                canvas.SetActive(false);
            }
            checkw45();
        }
    }


    private void checkw45()
    {
        float Sphx = this.Sphere.transform.position.x;
     
        if (Sphx >= w45.transform.position.x)
        {
            if(GameObject.Find("CLK").GetComponent<Run>().get_currentOperation().get_Name().Contains("str")){
                rend.enabled = false;
                done = true;
                canvas.SetActive(false);
            }
            w45_start = true;
            
        }
    }

    public bool w45_begin()
    {
        return this.w45_start;
    }

    public bool isdone()
    {
        return this.done;
    }

    public void reset()
    {
        done = false;
        first_move = true;
        canvas.SetActive(false);
        w45_start = false;
        Sphere.transform.localPosition = new Vector3(0f, -1f, 0f);
    }
}
