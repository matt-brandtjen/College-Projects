using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SphereController1512 : MonoBehaviour
{
    public GameObject inputObject;
    public GameObject Sphere;
    public GameObject VerticalWire;
    public GameObject canvas;
    public GameObject W26;
    
    private Renderer rend;
    private bool done = false;
    private bool VerticalWire_done = false;
    private bool first_move = true;
    private Instruction currentOperation;
    
    // Start is called before the first frame update
    void Start()
    {
        rend = Sphere.GetComponent<Renderer>();
        rend.enabled = false;
        canvas.SetActive(false);
    }
    
    // Sphere movement
    public void animate(){
        currentOperation = GameObject.Find("CLK").GetComponent<Run>().get_currentOperation();
        
        if(inputObject.GetComponent<Instr_SphereController>().isdone1512() && Sphere.transform.localPosition.y < 1 && !done){
            
            if(first_move){
                rend.enabled = true;
                first_move = false;
                canvas.SetActive(true);
            }
            
            Sphere.transform.Translate(new Vector3(0f,0f,-7f)*Time.deltaTime);
            
            if(Sphere.transform.position.x >= VerticalWire.transform.position.x){
                VerticalWire_done = true;
                if(currentOperation.get_Name().Contains("str")){
                    done = true;
                    rend.enabled = false;
                    canvas.SetActive(false);
                }
            }
        }
        else if(Sphere.transform.localPosition.y >= 1){
            
            rend.enabled = false;
            canvas.SetActive(false);
            done = true;
        }
         
    }
    
    public bool isdone(){
        return this.done;
    }
    
    public bool VerticalWire_isdone(){
        return VerticalWire_done;
    }
    
    public void reset(){
        done = false;
        VerticalWire_done = false;
        first_move = true;
        canvas.SetActive(false);
        Sphere.transform.localPosition = new Vector3(0f,-1f,0f);
    }

}
