using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class W69_SphereController : MonoBehaviour
{
    public GameObject inputObject;
    public GameObject Sphere;
    public GameObject w70B;
    private Renderer rend;
    private bool done = false;
    private bool first_move = true;
    private bool w70B_start = false;
    // Start is called before the first frame update
    void Start()
    {
        rend = Sphere.GetComponent<Renderer>();
        rend.enabled = false;
    }

    // Sphere movement
    void animate()
    {
        
        check();
        if (inputObject.GetComponent<W68_SphereController>().w69B_begin() && Sphere.transform.localPosition.y < 1 && !done)
        {
            if (first_move)
            {
                rend.enabled = true;
                first_move = false;
            }

            Sphere.transform.Translate(new Vector3(0f, 15f, 0f) * Time.deltaTime, Sphere.transform.parent);
        }
        else if (Sphere.transform.localPosition.y >= 1)
        {
            rend.enabled = false;

            done = true;
        }
    }

    public bool isdone()
    {
        return this.done;
    }
    private void check()
    {
        float Sphx = this.Sphere.transform.position.x;

        if (Sphx >= w70B.transform.position.x)
        {

            w70B_start = true;
        }
    }
    public bool w70B_begin()
    { 
        return this.w70B_start;
    }

    void reset()
    {
        done = false;
        first_move = true;
        Sphere.transform.localPosition = new Vector3(0f, -1f, 0f);
    }

}
