using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class W68_SphereController : MonoBehaviour
{
    public GameObject inputObject;
    public GameObject Sphere;
    public GameObject w69B;
    private Renderer rend;
    private bool done = false;
    private bool first_move = true;
    private bool w69B_start = false;
    // Start is called before the first frame update
    void Start()
    {
        rend = Sphere.GetComponent<Renderer>();
    }

    // Sphere movement
    void animate()
    {
        check();
        if ( !done && Sphere.transform.localPosition.y < 1)
        {

            if (first_move)
            {
                rend.enabled = true;
                first_move = false;
            }

            Sphere.transform.Translate(new Vector3(0f, 8f, 0f) * Time.deltaTime, Sphere.transform.parent);
        }
        else if (Sphere.transform.localPosition.y >= 1)
        {
            rend.enabled = false;
            done = true;
        }
    }


    private void check()
    {
        float Sphz = this.Sphere.transform.position.z;

        if (Sphz >= w69B.transform.position.z)
        {
            w69B_start = true;
        }
    }

    public bool w69B_begin()
    {
        return this.w69B_start;
    }

    public bool isdone()
    {
        return this.done;
    }

    void reset()
    {
        done = false;
        first_move = true;
        Sphere.transform.localPosition = new Vector3(0f, -1f, 0f);
    }
}
