using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Instr_SphereController : MonoBehaviour
{
    public GameObject inputObject;
    public GameObject Sphere_UP;
    public GameObject Sphere_DOWN;
    public GameObject Cond;

    public GameObject canvas;

    public GameObject canvas_down;
    public GameObject Op;
    public GameObject Funct;
    public GameObject Rd;
    public GameObject w1916;
    public GameObject w30;
    public GameObject w1512;
    public GameObject Pcplus4;
    public GameObject w230;

    private Vector3 Sphere_UP_init_Pos;
    private Vector3 Sphere_DOWN_init_Pos;
    
    private Renderer rend_UP;
    private Renderer rend_DOWN;
    
    private bool Cond_done = false;
    private bool Op_done = false;
    private bool Funct_done = false;
    private bool Rd_done = false;
    private bool done1916 = false;
    private bool done30 = false;
    private bool done1512 = false;
    private bool Pcplus4_done = false;
    private bool done230 = false;

    private bool first_move_UP = true;
    private bool first_move_DOWN = true;
    
    private bool move_UP_done = false;
    private bool move_DOWN_done = false;
    
    private Instruction currentOperation;
    private bool current_has_imm;
    
    // Start is called before the first frame update
    void Start()
    {
        Sphere_UP_init_Pos = Sphere_UP.transform.localPosition;
        Sphere_DOWN_init_Pos = Sphere_DOWN.transform.localPosition;
        
        rend_UP = Sphere_UP.GetComponent<Renderer>();
        rend_UP.enabled = false;
        rend_DOWN = Sphere_DOWN.GetComponent<Renderer>();
        rend_DOWN.enabled = false;
        canvas_down.SetActive(false);

        canvas.SetActive(false);
    }
    
    // Sphere movement
    public void animate(string which){
        switch (which) {
            case "UP":  UP_animate(); 
                break;
            case "DOWN": DOWN_animate();
                break;
            case "UPDOWN":{
                UP_animate();
                DOWN_animate();
            }
            break;
        }
        
    }
    
    void UP_animate(){
        
        if(inputObject.GetComponent<SphereController>().isdone() && Sphere_UP.transform.localPosition.y > -1 && !Cond_done && !move_UP_done){
            
            if (first_move_UP){
                rend_UP.enabled = true;
                first_move_UP = false;
                canvas.SetActive(true);

            }
             
            Sphere_UP.transform.Translate(new Vector3(0f,-15f,0f)*Time.deltaTime);
            
            float Sphz = Sphere_UP.transform.position.z;
            if(Sphz > Cond.transform.position.z){
                Cond_done = true;
            }
            if(Sphz > Op.transform.position.z){
                Op_done = true;
                canvas.SetActive(false);
                
                if(currentOperation.get_Name().Contains("add") ||
                   currentOperation.get_Name().Contains("sub") ||
                   currentOperation.get_Name().Contains("str") ||
                   currentOperation.get_Name().Contains("beq")){
                       move_UP_done = true;
                       rend_UP.enabled = false;
                   }
            }
            if(Sphz > Funct.transform.position.z){
                Funct_done = true;
            }
            if(Sphz > Rd.transform.position.z){
                Rd_done = true;
            }
            if(Sphz > w1916.transform.position.z){
                done1916 = true;
            }
        }
        else if(Cond_done){
            rend_UP.enabled = false;
        }
    }
    
    void DOWN_animate(){
        
        if(inputObject.GetComponent<SphereController>().isdone() && Sphere_DOWN.transform.localPosition.y < 1 && !done230 && !move_DOWN_done){
            
            if(first_move_DOWN){
                rend_DOWN.enabled = true;
                first_move_DOWN = false;
                currentOperation = GameObject.Find("CLK").GetComponent<Run>().get_currentOperation();
                current_has_imm = currentOperation.get_has_imm();
                canvas_down.SetActive(true);

            }

            Sphere_UP.transform.Translate(new Vector3(0f, -15f, 0f) * Time.deltaTime);
            float SphUPz = Sphere_UP.transform.position.z;
            if (SphUPz > w1916.transform.position.z)
                done1916 = true;
            

            Sphere_DOWN.transform.Translate(new Vector3(0f,15f,0f)*Time.deltaTime);
            
            float Sphz = Sphere_DOWN.transform.position.z;
            if(Sphz < w30.transform.position.z){
                
                done30 = true;
                
                if(currentOperation.get_Name().Contains("beq")){
                    //canvas.SetActive(false);
                    move_DOWN_done = true;
                    rend_DOWN.enabled = false;
                    canvas_down.SetActive(false);

                }
            }
            if(Sphz < w1512.transform.position.z){
                done1512 = true;
                if(!current_has_imm){
                    move_DOWN_done = true;
                    rend_DOWN.enabled = false;
                    canvas_down.SetActive(false);

                }
            }
            if(Sphz < Pcplus4.transform.position.z){
                Pcplus4_done = true;
            }
            if(Sphz < w230.transform.position.z){
                done230 = true;
            }
        }
        else if(done230){
            rend_DOWN.enabled = false;
            canvas_down.SetActive(false);

        }
    }
    
    // Cond
    public bool Cond_isdone(){
        return Cond_done;
    }
    
    // OP
    public bool Op_isdone(){
        return Op_done;
    }
    
    // Funct
    public bool Funct_isdone(){
        return Funct_done;
    }
    
    // Rd
    public bool Rd_isdone(){
        return Rd_done;
    }
    
    // 19:16
    public bool isdone1916(){
        return done1916;
    }
    
    // 3:0
    public bool isdone30(){
        return done30;
    }
    
    // 1512
    public bool isdone1512(){
        return done1512;
    }
    
    // PCPLUS4
    public bool Pcplus4_isdone(){
        return Pcplus4_done;
    }
    
    //23:0
    public bool isdone230(){
        return done230;
    }
    
    public void reset(){
        Sphere_UP.transform.localPosition = Sphere_UP_init_Pos;
        Sphere_DOWN.transform.localPosition = Sphere_DOWN_init_Pos;
        
        first_move_UP = true;
        first_move_DOWN = true;
        
        Cond_done = false;
        Op_done = false;
        Funct_done = false;
        Rd_done = false;
        done1916 = false;
        done30 = false;
        done1512 = false;
        Pcplus4_done = false;
        done230 = false;
        canvas_down.SetActive(false);

        move_UP_done = false;
        move_DOWN_done = false;

        canvas.SetActive(false);
    }
}
