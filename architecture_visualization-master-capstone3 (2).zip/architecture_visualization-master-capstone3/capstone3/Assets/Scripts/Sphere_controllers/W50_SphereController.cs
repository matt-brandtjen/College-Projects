using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class W50_SphereController : MonoBehaviour
{
    public GameObject inputObject;
    public GameObject Sphere;
    public GameObject canvas;
   
    private Renderer rend;
    private bool done = false;
    private bool first_move = true;
    
    // Start is called before the first frame update
    void Start()
    {
        rend = Sphere.GetComponent<Renderer>();
    }

    // Sphere movement
    public void animate()
    {

        if (inputObject.GetComponent<W49_SphereController>().w50_begin() && !done && Sphere.transform.localPosition.y < 1)
        {

            if (first_move)
            {
                canvas.SetActive(true);
                rend.enabled = true;
                first_move = false;
            }

            Sphere.transform.Translate(new Vector3(0f, 8f, 0f) * Time.deltaTime, Sphere.transform.parent);

        }
        else if (Sphere.transform.localPosition.y >= 1)
        {
            rend.enabled = false;
            done = true;
            canvas.SetActive(false);
        }
    }
 

    public bool isdone()
    {
        return this.done;
    }

    public void reset()
    {
        done = false;
        first_move = true;
        Sphere.transform.localPosition = new Vector3(0f, -1f, 0f);
    }
}
