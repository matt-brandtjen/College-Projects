using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CLK_SphereController : MonoBehaviour
{
    public GameObject inputObject;
    public GameObject Sphere;
    public GameObject w31B;
    public GameObject CLK;
    public GameObject canvas;   

    private Renderer rend;
    private bool done = false;
    private bool first_move = true;
    private bool w31B_start = false;
    // Start is called before the first frame update
    void Start()
    {
        rend = Sphere.GetComponent<Renderer>();
        rend.enabled = false;
        canvas.SetActive(false); 
    }

    // Sphere movement
    public void animate()
    {
        if(CLK.GetComponent<CLK_Calculate>().isdone()){
            check();

            if (Sphere.transform.localPosition.y < 1 && !done)
            {
                if (first_move)
                {
                    rend.enabled = true;
                    first_move = false;
                    canvas.SetActive(true);
                }

                Sphere.transform.Translate(new Vector3(0f, 4f, 0f) * Time.deltaTime, Sphere.transform.parent);
            }
            else if (Sphere.transform.localPosition.y >= 1)
            {
                rend.enabled = false;
                canvas.SetActive(false);
                done = true;
            }
        }
    }

    public bool isdone()
    {
        return this.done;
    }

    private void check()
    {
        float Sphx = this.Sphere.transform.position.x;
        if (Sphx > w31B.transform.position.x)
        {
            w31B_start = true;
        }
    }

    public bool w31B_begin()
    { 
        return this.w31B_start;
    }
    public void reset()
    {
        done = false;
        first_move = true;
        w31B_start = false;
        Sphere.transform.localPosition = new Vector3(0f, -1f, 0f);
    }

}

