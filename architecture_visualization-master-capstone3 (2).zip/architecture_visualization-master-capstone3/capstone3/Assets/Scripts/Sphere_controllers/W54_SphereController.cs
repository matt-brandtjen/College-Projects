using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class W54_SphereController : MonoBehaviour
{
    public GameObject W53;
    public GameObject Sphere;
    
    private Renderer rend;
    private bool done = false;
    private bool first_move = true;
    
    // Start is called before the first frame update
    void Start()
    {
        rend = Sphere.GetComponent<Renderer>();
        rend.enabled = false;
    }
    
    // Sphere movement
    public void animate(){
        
        if(W53.GetComponent<W53_SphereController>().isdone() && Sphere.transform.localPosition.y < 1 && !done){
            
            if(first_move){
                rend.enabled = true;
                first_move = false;
            }
             
            Sphere.transform.Translate(new Vector3(0f,0f,4f)*Time.deltaTime);
        }
        else if(Sphere.transform.localPosition.y >= 1){
            rend.enabled = false;
            
            done = true;
        }
    }
    
    public bool isdone(){
        return this.done;
    }
    
    public void reset(){
        done = false;
        first_move = true;
        Sphere.transform.localPosition = new Vector3(0f,-1f,0f);
    }

}
