using UnityEngine;

public class ControlUnit_Calculate : MonoBehaviour {
    public GameObject Op;
    
    private bool done = false;
    
    public void calculate(){
        if(Op.GetComponent<Op_SphereController>().isdone())
            done = true;
    }
    
    public bool isdone(){
        return this.done;
    }
    
    public void reset(){
        this.done = false;
    }
}

