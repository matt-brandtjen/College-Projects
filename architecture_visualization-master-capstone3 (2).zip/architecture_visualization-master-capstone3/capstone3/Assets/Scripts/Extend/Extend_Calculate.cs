using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Extend_Calculate : MonoBehaviour {
    public GameObject W230;
    
    private bool done = false;
    
    public void calculate(){
        if(W230.GetComponent<SphereController230>().isdone())
            done = true;
        
    }
    
    public bool isdone(){
        return this.done;
    }
    
    public void reset(){
        this.done = false;
    }
}
