using System.Collections;
using System.Collections.Generic;
using System;
using UnityEngine;

public class Str : Instruction {
    
    public Str(string rd, string rs, string rt, string imm, GameObject c) : 
        base(rd,rs,rt,imm,c){}
    
    public override void operate() {
        timeController();
        container_on();
        animateSpheres();
        
        // if animations are complete, set data memory from rd 
        if(GameObject.Find("Data Memory").GetComponent<DataMemory_Calculate>().isdone()) {
            container_off();
            int stored_value = Convert.ToInt32(GameObject.Find("Register File").GetComponent<RegisterFile>().get_RegisterVal(rd));
            string value_inhex = stored_value.ToString("X");
            string val_in_add = "0x";
            for(int i = 0; i < (8 - value_inhex.Length); i++){
                val_in_add += "0";
            }
            val_in_add += value_inhex;
            
            string mem_inhex = GameObject.Find("Register File").GetComponent<RegisterFile>().get_RegisterVal(rs);
            mem_inhex = (Convert.ToInt32(mem_inhex,16) + Convert.ToInt32(rt)).ToString("X");
            string mem_add = "0x";
            for(int i = 0; i < (8 - mem_inhex.Length); i++){
                mem_add += "0";
            }
            mem_add += mem_inhex;
            GameObject.Find("Data Memory").GetComponent<DataMemory_Calculate>().set_mem(mem_add, val_in_add);
            
            this.done = true;

            resetSpheres();
        }
    }

    public void animateSpheres() {
        GameObject.Find("CLK to IM").GetComponent<CLK_SphereController>().animate();
        GameObject.Find("Wire (31)").transform.GetChild(0).GetComponent<W31_SphereController>().animate();
        GameObject.Find("Wire (32)").transform.GetChild(0).GetComponent<W32_SphereController>().animate();
        GameObject.Find("PCPlus4").GetComponent<PCPlus4_Calculate>().calculate();
        GameObject.Find("Wire (11)").transform.GetChild(0).GetComponent<W11_SphereController>().animate();
        GameObject.Find("Wire (35)").transform.GetChild(0).GetComponent<W35_SphereController>().animate();
        GameObject.Find("Wire (34)").transform.GetChild(0).GetComponent<W34_SphereController>().animate();
        GameObject.Find("Wire (33)").transform.GetChild(0).GetComponent<W33_SphereController>().animate();
        GameObject.Find("Wire (29)").transform.GetChild(0).GetComponent<W29_SphereController>().animate();
        GameObject.Find("Instruction Memory").GetComponent<InstructionMemory_Calculate>().calculate();
        GameObject.Find("Wire (3)").GetComponent<SphereController>().animate();
        GameObject.Find("Instr").GetComponent<Instr_SphereController>().animate("UPDOWN");
        GameObject.Find("Op").GetComponent<Op_SphereController>().animate();
        GameObject.Find("Control Unit").GetComponent<ControlUnit_Calculate>().calculate();
        GameObject.Find("ALUControl").GetComponent<ALUControl_SphereController>().animate();
        GameObject.Find("Wire (62)").GetComponent<W62_SphereController>().animate();
        GameObject.Find("1916").GetComponent<SphereController1916>().animate();
        GameObject.Find("Mux RA1").GetComponent<MuxRA1_Calculate>().calculate();
        GameObject.Find("RA1").GetComponent<RA1_SphereController>().animate();
        GameObject.Find("1512").GetComponent<SphereController1512>().animate();
        GameObject.Find("Wire (26)").GetComponent<W26_SphereController>().animate();
        GameObject.Find("Wire (25)").GetComponent<W25_SphereController>().animate();
        GameObject.Find("Mux RA2").GetComponent<MuxRA2_Calculate>().calculate();
        GameObject.Find("RA2").GetComponent<RA2_SphereController>().animate();
        GameObject.Find("230").GetComponent<SphereController230>().animate();
        GameObject.Find("Extend").GetComponent<Extend_Calculate>().calculate();
        GameObject.Find("Register File").GetComponent<RegisterFile>().calculate();
        GameObject.Find("Wire (20)").transform.GetChild(0).GetComponent<W20_SphereController>().animate();
        GameObject.Find("Wire (38)").transform.GetChild(0).GetComponent<W38_SphereController>().animate();
        GameObject.Find("Mux Srcb").GetComponent<MuxSrcb_Calculate>().calculate();
        GameObject.Find("Wire (39)").transform.GetChild(0).GetComponent<W39_SphereController>().animate();
        GameObject.Find("ALU").GetComponent<ALU_Calculate>().calculate(false);
        GameObject.Find("Wire (40)").transform.GetChild(0).GetComponent<W40_SphereController>().animate();
        GameObject.Find("Wire (41)").transform.GetChild(0).GetComponent<W41_SphereController>().animate();
        GameObject.Find("Wire (42)").transform.GetChild(0).GetComponent<W42_SphereController>().animate();
        GameObject.Find("Wire (43)").transform.GetChild(0).GetComponent<W43_SphereController>().animate();
        GameObject.Find("Wire (44)").transform.GetChild(0).GetComponent<W44_SphereController>().animate();
        GameObject.Find("Wire (45)").transform.GetChild(0).GetComponent<W45_SphereController>().animate();
        GameObject.Find("Data Memory").GetComponent<DataMemory_Calculate>().calculate();
    }

    public void resetSpheres() {
        GameObject.Find("CLK to IM").GetComponent<CLK_SphereController>().reset();
        GameObject.Find("Wire (31)").transform.GetChild(0).GetComponent<W31_SphereController>().reset();
        GameObject.Find("Wire (32)").transform.GetChild(0).GetComponent<W32_SphereController>().reset();
        GameObject.Find("PCPlus4").GetComponent<PCPlus4_Calculate>().reset();
        GameObject.Find("Wire (11)").transform.GetChild(0).GetComponent<W11_SphereController>().reset();
        GameObject.Find("Wire (35)").transform.GetChild(0).GetComponent<W35_SphereController>().reset();
        GameObject.Find("Wire (34)").transform.GetChild(0).GetComponent<W34_SphereController>().reset();
        GameObject.Find("Wire (33)").transform.GetChild(0).GetComponent<W33_SphereController>().reset();
        GameObject.Find("Wire (29)").transform.GetChild(0).GetComponent<W29_SphereController>().reset();
        GameObject.Find("Instruction Memory").GetComponent<InstructionMemory_Calculate>().reset();
        GameObject.Find("Wire (3)").GetComponent<SphereController>().reset();
        GameObject.Find("Instr").GetComponent<Instr_SphereController>().reset();
        GameObject.Find("Op").GetComponent<Op_SphereController>().reset();
        GameObject.Find("Control Unit").GetComponent<ControlUnit_Calculate>().reset();
        GameObject.Find("ALUControl").GetComponent<ALUControl_SphereController>().reset();
        GameObject.Find("Wire (62)").GetComponent<W62_SphereController>().reset();
        GameObject.Find("1916").GetComponent<SphereController1916>().reset();
        GameObject.Find("Mux RA1").GetComponent<MuxRA1_Calculate>().reset();
        GameObject.Find("RA1").GetComponent<RA1_SphereController>().reset();
        GameObject.Find("1512").GetComponent<SphereController1512>().reset();
        GameObject.Find("Wire (26)").GetComponent<W26_SphereController>().reset();
        GameObject.Find("Wire (25)").GetComponent<W25_SphereController>().reset();
        GameObject.Find("Mux RA2").GetComponent<MuxRA2_Calculate>().reset();
        GameObject.Find("RA2").GetComponent<RA2_SphereController>().reset();
        GameObject.Find("230").GetComponent<SphereController230>().reset();
        GameObject.Find("Extend").GetComponent<Extend_Calculate>().reset();
        GameObject.Find("Register File").GetComponent<RegisterFile>().reset();
        GameObject.Find("Wire (20)").transform.GetChild(0).GetComponent<W20_SphereController>().reset();
        GameObject.Find("Wire (38)").transform.GetChild(0).GetComponent<W38_SphereController>().reset();
        GameObject.Find("Mux Srcb").GetComponent<MuxSrcb_Calculate>().reset();
        GameObject.Find("Wire (39)").transform.GetChild(0).GetComponent<W39_SphereController>().reset();
        GameObject.Find("ALU").GetComponent<ALU_Calculate>().reset();
        GameObject.Find("Wire (40)").transform.GetChild(0).GetComponent<W40_SphereController>().reset();
        GameObject.Find("Wire (41)").transform.GetChild(0).GetComponent<W41_SphereController>().reset();
        GameObject.Find("Wire (42)").transform.GetChild(0).GetComponent<W42_SphereController>().reset();
        GameObject.Find("Wire (43)").transform.GetChild(0).GetComponent<W43_SphereController>().reset();
        GameObject.Find("Wire (44)").transform.GetChild(0).GetComponent<W44_SphereController>().reset();
        GameObject.Find("Wire (45)").transform.GetChild(0).GetComponent<W45_SphereController>().reset();
        GameObject.Find("Data Memory").GetComponent<DataMemory_Calculate>().reset();
    }
    
    public override bool get_has_imm() {
        return true;
    }
    
    public override string get_Name() {
        return "str";
    }
}
