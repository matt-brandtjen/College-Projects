using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System.Globalization;
using System;

public class NameTransfer : MonoBehaviour {
    public Transform dropdownMenu;
    public Transform dropdownMenu_1;

    public string txt_rd;
    public string txt_rs;
    public string txt_rt;

    public GameObject input_rd; 
    public GameObject input_rs;
    public GameObject input_rt;

    public GameObject memory_out_1;
    public GameObject memory_out_2;
    public GameObject memory_out_3;

    public GameObject display_Address;          //Instr - sphere_UP_
    public GameObject display_Operation_1;      //ALUControl
    public GameObject display_Operation_2;      //Wire62
    public GameObject display_Operation_3;      //Op

    public GameObject display_rd;               //1512
    public GameObject display_rs;               //RA1
    public GameObject display_rt;               //RA2
    public GameObject display_All;              //CLK to IM
    public GameObject display_All_1;            //Wire(3)
    public GameObject display_rd_N;             //43
    public GameObject display_rd_N_1;           //52
    public GameObject display_rd_N_2;           //52
    public GameObject display_rd_N_3;           //36
    public GameObject display_rd_N_4;           //37
    public GameObject display_rd_N_5;           //47
    public GameObject display_rd_N_6;           //46
    public GameObject display_rd_N_7;           //30
    public GameObject display_rd_N_8;           //51
    public GameObject display_rs_N;             //20


    public GameObject display_number_230;       
	public GameObject display_number_42;
	public GameObject display_number_41;
	public GameObject display_number_40;
    public GameObject display_number_27;
    public GameObject display_number_28;
    public GameObject display_down;

    public GameObject display_number_31;       
    public GameObject display_number_32;

    public GameObject display_number_11;
    public GameObject display_number_35;
    public GameObject display_number_34;
    public GameObject display_number_33;
    public GameObject display_number_29;

    public GameObject display_number_44;
    public GameObject display_number_45;

    public GameObject display_rt_N;         //38
    public GameObject display_rt_N_1;       //39
    public GameObject RF;
    public GameObject addr;

    public GameObject DM;

    // Sets the values for the textboxes that follow the spheres.
    public void storeData() {
        // Get instruction from Operation List
        int menuIndex = dropdownMenu.GetComponent<Dropdown>().value;
        List<Dropdown.OptionData> menuOptions = dropdownMenu.GetComponent<Dropdown>().options;
        string operation = menuOptions[menuIndex].text;

        // Get instruction address and calculate next instruction address
        string current_addr = addr.GetComponent<Text>().text;  
        int address = Convert.ToInt32(current_addr.Replace("0x",""), 16);
        int new_addr = address+4;

        // Get register values
        txt_rd = input_rd.GetComponent<Text>().text.ToUpper();
        txt_rs = input_rs.GetComponent<Text>().text.ToUpper();
        txt_rt = input_rt.GetComponent<Text>().text.ToUpper();

        display_Address.GetComponent<Text>().text = operation + " " + txt_rd + " " + txt_rs + " " + txt_rt;
        display_down.GetComponent<Text>().text = operation + " " + txt_rd + " " + txt_rs + " " + txt_rt;

        display_All.GetComponent<Text>().text =  addr.GetComponent<Text>().text; 
        display_All_1.GetComponent<Text>().text = operation + " " + txt_rd + " " + txt_rs + " " + txt_rt;
        display_Operation_1.GetComponent<Text>().text = operation;
        display_Operation_2.GetComponent<Text>().text = operation;
        display_Operation_3.GetComponent<Text>().text = operation;

        display_number_31.GetComponent<Text>().text =  addr.GetComponent<Text>().text;
        display_number_32.GetComponent<Text>().text =  addr.GetComponent<Text>().text;

        //after pc+4
        display_number_11.GetComponent<Text>().text =  "0x" + new_addr.ToString("X4");
        display_number_35.GetComponent<Text>().text =  "0x" + new_addr.ToString("X4");
        display_number_34.GetComponent<Text>().text =  "0x" + new_addr.ToString("X4");
        display_number_33.GetComponent<Text>().text =  "0x" + new_addr.ToString("X4");
        display_number_29.GetComponent<Text>().text =  "0x" + new_addr.ToString("X4");
        

        if (operation == "mov") {
            display_rd.GetComponent<Text>().text = txt_rd;
            display_rs.GetComponent<Text>().text = txt_rs;
            display_rt.GetComponent<Text>().text = txt_rt;
            display_rs_N.GetComponent<Text>().text = readData(txt_rs).ToString("");
            display_number_230.GetComponent<Text>().text = txt_rs;
            display_number_40.GetComponent<Text>().text = txt_rs;
            display_number_41.GetComponent<Text>().text = txt_rs;
            display_number_42.GetComponent<Text>().text = txt_rs;

            if (txt_rs.Contains("R")) {
                double result = Convert.ToDouble(readData(txt_rs));
                display_rd_N.GetComponent<Text>().text = result.ToString();
                display_rt_N_1.GetComponent<Text>().text = result.ToString();
                display_rd_N_2.GetComponent<Text>().text = result.ToString();
                display_rd_N_3.GetComponent<Text>().text = result.ToString();
                display_rd_N_4.GetComponent<Text>().text = result.ToString();
                display_rd_N_5.GetComponent<Text>().text = result.ToString();
                display_rd_N_6.GetComponent<Text>().text = result.ToString();
                display_rd_N_7.GetComponent<Text>().text = result.ToString();
                display_rd_N_8.GetComponent<Text>().text = result.ToString();
            } else { 
                display_rd_N.GetComponent<Text>().text = txt_rs;
                display_rt_N_1.GetComponent<Text>().text = txt_rs;
                display_rd_N_2.GetComponent<Text>().text = txt_rs;
                display_rd_N_3.GetComponent<Text>().text = txt_rs;
                display_rd_N_4.GetComponent<Text>().text = txt_rs;
                display_rd_N_5.GetComponent<Text>().text = txt_rs;
                display_rd_N_6.GetComponent<Text>().text = txt_rs;
                display_rd_N_7.GetComponent<Text>().text = txt_rs;
                display_rd_N_8.GetComponent<Text>().text = txt_rs;
            }
        }

        else if (operation == "sub") {
            string s = "";
            display_rd.GetComponent<Text>().text = txt_rd;
            display_rs.GetComponent<Text>().text = txt_rs;
            display_rt.GetComponent<Text>().text = txt_rt;
            display_rs_N.GetComponent<Text>().text = readData(txt_rs).ToString(s);

        	if (!RF.GetComponent<RegisterFile>().ContainsR(txt_rt)) {
        		double result = Convert.ToDouble(readData(txt_rs)) - Convert.ToDouble(txt_rt);
        		display_rd_N_1.GetComponent<Text>().text = result.ToString(s);
            	display_rd_N.GetComponent<Text>().text = result.ToString(s);
            	
            	display_rd_N_2.GetComponent<Text>().text = result.ToString(s);
            	display_rd_N_3.GetComponent<Text>().text = result.ToString(s);
            	display_rd_N_4.GetComponent<Text>().text = result.ToString(s);
            	display_rd_N_5.GetComponent<Text>().text = result.ToString(s);
            	display_rd_N_6.GetComponent<Text>().text = result.ToString(s);
            	display_rd_N_7.GetComponent<Text>().text = result.ToString(s);
            	display_rd_N_8.GetComponent<Text>().text = result.ToString(s);
            	display_number_230.GetComponent<Text>().text = txt_rt;
				display_number_42.GetComponent<Text>().text = txt_rt;
				display_number_41.GetComponent<Text>().text = txt_rt;
				display_number_40.GetComponent<Text>().text = txt_rt;
				
        		display_rt_N_1.GetComponent<Text>().text = txt_rt;
        	} else {
        		double result = Convert.ToDouble(readData(txt_rs)) - Convert.ToDouble(readData(txt_rt));
           	 	display_rd_N_1.GetComponent<Text>().text = result.ToString(s);
            	display_rd_N.GetComponent<Text>().text = result.ToString(s);
            	
            	display_rd_N_2.GetComponent<Text>().text = result.ToString(s);
            	display_rd_N_3.GetComponent<Text>().text = result.ToString(s);
            	display_rd_N_4.GetComponent<Text>().text = result.ToString(s);
            	display_rd_N_5.GetComponent<Text>().text = result.ToString(s);
            	display_rd_N_6.GetComponent<Text>().text = result.ToString(s);
            	display_rd_N_7.GetComponent<Text>().text = result.ToString(s);
            	display_rd_N_8.GetComponent<Text>().text = result.ToString(s);
            	display_rt_N.GetComponent<Text>().text = readData(txt_rt).ToString(s);
        		display_rt_N_1.GetComponent<Text>().text = readData(txt_rt).ToString(s);
        	}
        }

        else if (operation == "add") {
            display_rd.GetComponent<Text>().text = txt_rd;
            display_rs.GetComponent<Text>().text = txt_rs;
            display_rt.GetComponent<Text>().text = txt_rt;

            string s = "";
            display_rs_N.GetComponent<Text>().text = readData(txt_rs).ToString(s);

        	if (!RF.GetComponent<RegisterFile>().ContainsR(txt_rt)) {
        		double result = Convert.ToDouble(readData(txt_rs)) + Convert.ToDouble(txt_rt);
        		display_rd_N_1.GetComponent<Text>().text = result.ToString(s);
            	display_rd_N.GetComponent<Text>().text = result.ToString(s);
            	
            	display_rd_N_2.GetComponent<Text>().text = result.ToString(s);
            	display_rd_N_3.GetComponent<Text>().text = result.ToString(s);
            	display_rd_N_4.GetComponent<Text>().text = result.ToString(s);
            	display_rd_N_5.GetComponent<Text>().text = result.ToString(s);
            	display_rd_N_6.GetComponent<Text>().text = result.ToString(s);
            	display_rd_N_7.GetComponent<Text>().text = result.ToString(s);
            	display_rd_N_8.GetComponent<Text>().text = result.ToString(s);
            	display_number_230.GetComponent<Text>().text = txt_rt;
				display_number_42.GetComponent<Text>().text = txt_rt;
				display_number_41.GetComponent<Text>().text = txt_rt;
				display_number_40.GetComponent<Text>().text = txt_rt;

                display_rt_N_1.GetComponent<Text>().text = txt_rt;
        	} else {
        		double result = Convert.ToDouble(readData(txt_rs)) + Convert.ToDouble(readData(txt_rt));
           	 	display_rd_N_1.GetComponent<Text>().text = result.ToString(s);
            	display_rd_N.GetComponent<Text>().text = result.ToString(s);
            	
            	display_rd_N_2.GetComponent<Text>().text = result.ToString(s);
            	display_rd_N_3.GetComponent<Text>().text = result.ToString(s);
            	display_rd_N_4.GetComponent<Text>().text = result.ToString(s);
            	display_rd_N_5.GetComponent<Text>().text = result.ToString(s);
            	display_rd_N_6.GetComponent<Text>().text = result.ToString(s);
            	display_rd_N_7.GetComponent<Text>().text = result.ToString(s);
            	display_rd_N_8.GetComponent<Text>().text = result.ToString(s);
            	display_rt_N.GetComponent<Text>().text = readData(txt_rt).ToString(s);
        		display_rt_N_1.GetComponent<Text>().text = readData(txt_rt).ToString(s);
        	}
        }

        else if (operation == "beq") {
            int menuIndex_1 = dropdownMenu_1.GetComponent<Dropdown>().value;
            List<Dropdown.OptionData> menuOptions_1 = dropdownMenu_1.GetComponent<Dropdown>().options;
            string value_1 = menuOptions_1[menuIndex_1].text;

            display_rs.GetComponent<Text>().text = txt_rd;
            display_rt.GetComponent<Text>().text = txt_rs;
            display_number_42.GetComponent<Text>().text = "label" + value_1;
            display_number_41.GetComponent<Text>().text = "label" + value_1;
            display_number_40.GetComponent<Text>().text = "label" + value_1;

            int result = 0;
            if ( Convert.ToDouble(readData(txt_rd)) == Convert.ToDouble(readData(txt_rs)) )
                result= 1;
            
            string s = "";
            display_rt_N.GetComponent<Text>().text = readData(txt_rs).ToString(s);
            display_rt_N_1.GetComponent<Text>().text = readData(txt_rs).ToString(s);
            
            display_rs_N.GetComponent<Text>().text = readData(txt_rd).ToString(s);

            display_rd_N.GetComponent<Text>().text = result.ToString(s);
            display_rd_N_5.GetComponent<Text>().text = result.ToString(s);
            display_rd_N_6.GetComponent<Text>().text = result.ToString(s);

            display_rd_N_1.GetComponent<Text>().text = result.ToString(s);
            display_rd_N_8.GetComponent<Text>().text = result.ToString(s);
            display_rd_N_7.GetComponent<Text>().text = result.ToString(s);
            display_number_27.GetComponent<Text>().text = result.ToString(s);
            display_number_28.GetComponent<Text>().text = result.ToString(s);
        }


        if (operation == "str") {
            operation = "add";
            string s = "";
            display_rd.GetComponent<Text>().text = txt_rd;
            display_rs.GetComponent<Text>().text = txt_rs;
            display_rt.GetComponent<Text>().text = txt_rd;
            display_rs_N.GetComponent<Text>().text = readData(txt_rs).ToString(s);

            display_rt_N.GetComponent<Text>().text = readData(txt_rd).ToString(s);   //38

            display_number_44.GetComponent<Text>().text = readData(txt_rd).ToString(s);
            display_number_45.GetComponent<Text>().text = readData(txt_rd).ToString(s);
            display_number_230.GetComponent<Text>().text = txt_rt;
            display_number_42.GetComponent<Text>().text = txt_rt;
            display_number_41.GetComponent<Text>().text = txt_rt;
            display_number_40.GetComponent<Text>().text = txt_rt;
            display_rt_N_1.GetComponent<Text>().text = txt_rt;
            
            string mem_inhex = GameObject.Find("Register File").GetComponent<RegisterFile>().get_RegisterVal(txt_rs);
            mem_inhex = (Convert.ToInt32(mem_inhex,16) + Convert.ToInt32(txt_rt)).ToString("X");
            string mem_add = "0x";
            for(int i = 0; i < (8 - mem_inhex.Length); i++) {
                mem_add += "0";
            }
            mem_add += mem_inhex;

            display_rd_N.GetComponent<Text>().text = mem_add;
        }

        else if (operation == "ldr") {
            string s = "";
            display_rd.GetComponent<Text>().text = txt_rd;
            display_rs.GetComponent<Text>().text = txt_rs;
            display_rt.GetComponent<Text>().text = txt_rd;
            display_rs_N.GetComponent<Text>().text = readData(txt_rs).ToString(s);

            display_rt_N.GetComponent<Text>().text = readData(txt_rd).ToString(s);   //38

            display_number_44.GetComponent<Text>().text = readData(txt_rd).ToString(s);
            display_number_45.GetComponent<Text>().text = readData(txt_rd).ToString(s);
            display_number_230.GetComponent<Text>().text = txt_rt;
            display_number_42.GetComponent<Text>().text = txt_rt;
            display_number_41.GetComponent<Text>().text = txt_rt;
            display_number_40.GetComponent<Text>().text = txt_rt;
            display_rt_N_1.GetComponent<Text>().text = txt_rt;

            string mem_inhex = GameObject.Find("Register File").GetComponent<RegisterFile>().get_RegisterVal(txt_rs);
            mem_inhex = (Convert.ToInt32(mem_inhex, 16) + Convert.ToInt32(txt_rt)).ToString("X");
            string mem_add = "0x";
            for (int i = 0; i < (8 - mem_inhex.Length); i++) {
                mem_add += "0";
            }
            mem_add += mem_inhex;
            display_rd_N.GetComponent<Text>().text = mem_add;

            string retrieved_val = DM.GetComponent<DataMemory_Calculate>().get_mem(mem_add);
            // trims '0x' off of string
            retrieved_val = retrieved_val.Remove(0, 2);
            int retrieved_val_int = int.Parse(retrieved_val, System.Globalization.NumberStyles.HexNumber);
            retrieved_val = retrieved_val_int.ToString();
            
            memory_out_1.GetComponent<Text>().text = retrieved_val;
            memory_out_2.GetComponent<Text>().text = retrieved_val;
            memory_out_3.GetComponent<Text>().text = retrieved_val;

            display_rd_N_1.GetComponent<Text>().text = retrieved_val;
            display_rd_N_2.GetComponent<Text>().text = retrieved_val;
            display_rd_N_3.GetComponent<Text>().text = retrieved_val;
            display_rd_N_4.GetComponent<Text>().text = retrieved_val;
            display_rd_N_5.GetComponent<Text>().text = retrieved_val;
            display_rd_N_6.GetComponent<Text>().text = retrieved_val;
            display_rd_N_7.GetComponent<Text>().text = retrieved_val;
            display_rd_N_8.GetComponent<Text>().text = retrieved_val;
        }
    }

    private double readData(string r) {
        string value = RF.GetComponent<RegisterFile>().get_RegisterVal(r);
        
        if (value.Contains("x"))
            return Convert.ToInt32(value,16);
        
        else
            return Convert.ToDouble(value);
    }

    



    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }



    
}
