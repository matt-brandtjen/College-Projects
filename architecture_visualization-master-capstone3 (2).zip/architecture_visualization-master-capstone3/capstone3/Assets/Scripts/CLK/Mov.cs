using System.Collections;
using System;
using System.Collections.Generic;
using UnityEngine;

public class Mov : Instruction {
    public Mov(string rd, string rs, string rt, string imm, GameObject container) :
        base(rd, rs, rt, imm, container) 
    { }

    public override void operate() {
        timeController();
        container_on();
        animateSpheres();

        // if the last spheres has finsihed animation, set the register val
        if (GameObject.Find("Wire (36)").transform.GetChild(0).GetComponent<W36_SphereController>().isdone() && 
            GameObject.Find("Wire (29)").transform.GetChild(0).GetComponent<W29_SphereController>().isdone()) {
            
            this.done = true;
            container_off();

            if (has_imm) 
                GameObject.Find("Register File").GetComponent<RegisterFile>().set_Register(rd, rs);
            else {
                string rsval = GameObject.Find("Register File").GetComponent<RegisterFile>().get_RegisterVal(rs).ToString();
                GameObject.Find("Register File").GetComponent<RegisterFile>().set_Register(rd, rsval);
            }

            resetSpheres();
        }
    }
    
    public override string get_Name() {
        return "mov";
    }
    
    public override bool get_has_imm() {
        return this.has_imm;
    }

    public void animateSpheres() {
        GameObject.Find("CLK to IM").GetComponent<CLK_SphereController>().animate();
        GameObject.Find("Wire (31)").transform.GetChild(0).GetComponent<W31_SphereController>().animate();
        GameObject.Find("Wire (32)").transform.GetChild(0).GetComponent<W32_SphereController>().animate();
        GameObject.Find("PCPlus4").GetComponent<PCPlus4_Calculate>().calculate();
        GameObject.Find("Wire (11)").transform.GetChild(0).GetComponent<W11_SphereController>().animate();
        GameObject.Find("Wire (35)").transform.GetChild(0).GetComponent<W35_SphereController>().animate();
        GameObject.Find("Wire (34)").transform.GetChild(0).GetComponent<W34_SphereController>().animate();
        GameObject.Find("Wire (33)").transform.GetChild(0).GetComponent<W33_SphereController>().animate();
        GameObject.Find("Wire (29)").transform.GetChild(0).GetComponent<W29_SphereController>().animate();
        GameObject.Find("Instruction Memory").GetComponent<InstructionMemory_Calculate>().calculate();
        GameObject.Find("Wire (3)").GetComponent<SphereController>().animate();
        GameObject.Find("Instr").GetComponent<Instr_SphereController>().animate("DOWN");
        GameObject.Find("Wire (53)").GetComponent<W53_SphereController>().animate();
        GameObject.Find("Wire (54)").GetComponent<W54_SphereController>().animate();
        GameObject.Find("1512").GetComponent<SphereController1512>().animate();

        if (!has_imm) {
            GameObject.Find("1916").GetComponent<SphereController1916>().animate();
            GameObject.Find("Mux RA1").GetComponent<MuxRA1_Calculate>().calculate();
            GameObject.Find("RA1").GetComponent<RA1_SphereController>().animate();
            GameObject.Find("Register File").GetComponent<RegisterFile>().calculate();

            GameObject.Find("Wire (20)").transform.GetChild(0).GetComponent<W20_SphereController>().animate();
        } else {
            GameObject.Find("230").GetComponent<SphereController230>().animate();
            GameObject.Find("Extend").GetComponent<Extend_Calculate>().calculate();
            GameObject.Find("Wire (42)").transform.GetChild(0).GetComponent<W42_SphereController>().animate();
            GameObject.Find("Wire (41)").transform.GetChild(0).GetComponent<W41_SphereController>().animate();
            GameObject.Find("Wire (40)").transform.GetChild(0).GetComponent<W40_SphereController>().animate();
            GameObject.Find("Mux Srcb").GetComponent<MuxSrcb_Calculate>().calculate();
            GameObject.Find("Wire (39)").transform.GetChild(0).GetComponent<W39_SphereController>().animate();
        }

        GameObject.Find("ALU").GetComponent<ALU_Calculate>().calculate(true);

        GameObject.Find("Wire (43)").transform.GetChild(0).GetComponent<W43_SphereController>().animate();
        GameObject.Find("Wire (46)").transform.GetChild(0).GetComponent<W46_SphereController>().animate();
        GameObject.Find("Wire (47)").transform.GetChild(0).GetComponent<W47_SphereController>().animate();
        GameObject.Find("Mux Result").GetComponent<MuxResult_Calculate>().calculate();
        GameObject.Find("Wire (52)").transform.GetChild(0).GetComponent<W52_SphereController>().animate();
        GameObject.Find("Wire (51)").transform.GetChild(0).GetComponent<W51_SphereController>().animate();
        GameObject.Find("Wire (30)").transform.GetChild(0).GetComponent<W30_SphereController>().animate();
        GameObject.Find("Wire (37)").transform.GetChild(0).GetComponent<W37_SphereController>().animate();
        GameObject.Find("Wire (36)").transform.GetChild(0).GetComponent<W36_SphereController>().animate();
    }

    public void resetSpheres() {
        GameObject.Find("CLK to IM").GetComponent<CLK_SphereController>().reset();
        GameObject.Find("Wire (31)").transform.GetChild(0).GetComponent<W31_SphereController>().reset();
        GameObject.Find("Wire (32)").transform.GetChild(0).GetComponent<W32_SphereController>().reset();
        GameObject.Find("PCPlus4").GetComponent<PCPlus4_Calculate>().reset();
        GameObject.Find("Wire (11)").transform.GetChild(0).GetComponent<W11_SphereController>().reset();
        GameObject.Find("Wire (35)").transform.GetChild(0).GetComponent<W35_SphereController>().reset();
        GameObject.Find("Wire (34)").transform.GetChild(0).GetComponent<W34_SphereController>().reset();
        GameObject.Find("Wire (33)").transform.GetChild(0).GetComponent<W33_SphereController>().reset();
        GameObject.Find("Wire (29)").transform.GetChild(0).GetComponent<W29_SphereController>().reset();
        GameObject.Find("Instruction Memory").GetComponent<InstructionMemory_Calculate>().reset();
        GameObject.Find("Wire (3)").GetComponent<SphereController>().reset();
        GameObject.Find("Instr").GetComponent<Instr_SphereController>().reset();
        GameObject.Find("Wire (53)").GetComponent<W53_SphereController>().reset();
        GameObject.Find("Wire (54)").GetComponent<W54_SphereController>().reset();
        GameObject.Find("1512").GetComponent<SphereController1512>().reset();

        if (!has_imm) {
            GameObject.Find("1916").GetComponent<SphereController1916>().reset();
            GameObject.Find("Mux RA1").GetComponent<MuxRA1_Calculate>().reset();
            GameObject.Find("RA1").GetComponent<RA1_SphereController>().reset();
            GameObject.Find("Register File").GetComponent<RegisterFile>().reset();

            GameObject.Find("Wire (20)").transform.GetChild(0).GetComponent<W20_SphereController>().reset();
        } else {
            GameObject.Find("230").GetComponent<SphereController230>().reset();
            GameObject.Find("Extend").GetComponent<Extend_Calculate>().reset();
            GameObject.Find("Wire (42)").transform.GetChild(0).GetComponent<W42_SphereController>().reset();
            GameObject.Find("Wire (41)").transform.GetChild(0).GetComponent<W41_SphereController>().reset();
            GameObject.Find("Wire (40)").transform.GetChild(0).GetComponent<W40_SphereController>().reset();
            GameObject.Find("Mux Srcb").GetComponent<MuxSrcb_Calculate>().reset();
            GameObject.Find("Wire (39)").transform.GetChild(0).GetComponent<W39_SphereController>().reset();
        }

        GameObject.Find("ALU").GetComponent<ALU_Calculate>().reset();

        GameObject.Find("Wire (43)").transform.GetChild(0).GetComponent<W43_SphereController>().reset();
        GameObject.Find("Wire (46)").transform.GetChild(0).GetComponent<W46_SphereController>().reset();
        GameObject.Find("Wire (47)").transform.GetChild(0).GetComponent<W47_SphereController>().reset();
        GameObject.Find("Mux Result").GetComponent<MuxResult_Calculate>().reset();
        GameObject.Find("Wire (52)").transform.GetChild(0).GetComponent<W52_SphereController>().reset();
        GameObject.Find("Wire (51)").transform.GetChild(0).GetComponent<W51_SphereController>().reset();
        GameObject.Find("Wire (30)").transform.GetChild(0).GetComponent<W30_SphereController>().reset();
        GameObject.Find("Wire (37)").transform.GetChild(0).GetComponent<W37_SphereController>().reset();
        GameObject.Find("Wire (36)").transform.GetChild(0).GetComponent<W36_SphereController>().reset();
    }
}
