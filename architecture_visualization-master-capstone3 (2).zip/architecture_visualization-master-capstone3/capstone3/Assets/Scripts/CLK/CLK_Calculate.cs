using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CLK_Calculate : MonoBehaviour {
    public GameObject PC_to_CLK;
    
    private bool done = true;
    
    public void calculate() {
        if(PC_to_CLK.GetComponent<PC_SphereController>().isdone()){
            
        }
    }
    
    public bool isdone() {
        return done;
    }
     
}
