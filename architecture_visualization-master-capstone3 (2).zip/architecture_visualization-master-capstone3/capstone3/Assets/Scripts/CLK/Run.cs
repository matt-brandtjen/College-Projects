using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public static class Util {
    // Util function to find inactive child Gameactive_objects.
    public static GameObject FindObject(this GameObject parent, string name) {
        Transform[] trs = parent.GetComponentsInChildren<Transform>(true);
        foreach (Transform t in trs) {
            if (t.name == name) {
                return t.gameObject;
            }
        }
        return null;
    }
}

public class Run : MonoBehaviour {
    public GameObject thisButton;
    public GameObject OperationContent;
    private Instruction currentOperation;
    private List<Instruction> operations;
    private int num_operations;
    
    private int i = 0;

    private bool firsttime = true;
    private bool done = false;
    private bool pause = true;
    
    void Update() {
        run();
    }
    
    public void set_Pause() {
        if(GameObject.Find("Run Button").GetComponent<AddtoPC>().noerror() && GameObject.Find("Run Button").GetComponent<AddtoPC>().isclicked()){
            pause = !pause;
            GameObject.Find("Run Button").GetComponent<Image_Switch>().switchIcon();
        }
    }
    
    public bool get_Pause() {
        return pause;
    }
    
    public void set_i(int i) {
        this.i = i;
    }
    
    void run() {
        if (!done && !pause){
            if (firsttime){
                operations = thisButton.GetComponent<AddtoPC>().get_operations();
                OperationContent.transform.GetChild(i).transform.GetComponent<NameTransfer>().storeData();

                bool assess_enabled = GameObject.Find("Assessment Toggle").GetComponent<AssessmentToggle>().is_active;
                if (assess_enabled) {
                    var success = assess(operations[i]);
                    if (!success) 
                        done = true;
                }

                num_operations = operations.Count;
                firsttime = false;
                currentOperation = operations[i];
            }
            
            else {
                if (i == num_operations)
                    done = true;
                else if (currentOperation.isdone()) {
                    currentOperation.set_done(false);
                    if (!currentOperation.get_Name().Contains("beq"))
                       i++; 

                    if (i <= num_operations-1) {
                        OperationContent.transform.GetChild(i).transform.GetComponent<NameTransfer>().storeData();
                        currentOperation = operations[i];
                    }
                }
                else currentOperation.operate();
            }
            
        }
        if (done){
            this.firsttime = true;
            this.done = false;
            this.pause = true;
            GameObject.Find("Run Button").GetComponent<Image_Switch>().set_Icon_play();
            GameObject.Find("Run Button").GetComponent<AddtoPC>().set_click_f();
            this.i = 0;
        }
    }

    // Returns true if the assessment passes.
    bool assess(Instruction instr) {
        var assessment_input = GameObject.Find("Assessment Input");
        var instr_type = instr.GetType();

        // Keys are the names of the assessment input field objects active in the scene.
        // Values are the names of the wires that should be checked against the keys.
        Dictionary<string, string> active_objects = new Dictionary<string, string>();
        var correct_input = true;

        // Create dictionary needed for a given instruction.
        if (instr_type == typeof(Mov)) {
            if (!instr.get_has_imm()) {
                active_objects = new Dictionary<string, string> {
                    { "CLK to IM assess", "CLK to IM" },
                    { "assess 30", "Wire (30)" },
                    { "assess 11", "Wire (11)" },
                    { "assess instr", "Instr" },
                    { "assess 1512", "1512" },
                    { "assess RA1", "RA1" },
                    { "assess 20", "Wire (20)" },
                    { "assess 43", "Wire (43)" },
                    { "assess 46", "Wire (46)" },
                };
            } else {
                active_objects = new Dictionary<string, string> {
                    { "CLK to IM assess", "CLK to IM" },
                    { "assess 30", "Wire (30)" },
                    { "assess 11", "Wire (11)" },
                    { "assess instr", "Instr" },
                    { "assess 1512", "1512" },
                    { "assess 230", "230" },
                    { "assess 39", "Wire (39)" },
                    { "assess 43", "Wire (43)" },
                    { "assess 46", "Wire (46)" }
                };
            }
        }

        else if (instr_type == typeof(Add) || instr_type == typeof(Sub)) { 
            if (!instr.get_has_imm()) {
                active_objects = new Dictionary<string, string> {
                    { "CLK to IM assess", "CLK to IM" },
                    { "assess 30", "Wire (30)" },
                    { "assess 11", "Wire (11)" },
                    { "assess instr", "Instr" },
                    { "assess 1512", "1512" },
                    { "assess RA1", "RA1" },
                    { "assess RA2", "RA2" },
                    { "assess 20", "Wire (20)" },
                    { "assess 38", "Wire (38)" },
                    { "assess 39", "Wire (39)" },
                    { "assess 43", "Wire (43)" },
                    { "assess 46", "Wire (46)" },
                    { "assess ALUControl", "ALUControl" },
                };
            }
            else {
                active_objects = new Dictionary<string, string> {
                    { "CLK to IM assess", "CLK to IM" },
                    { "assess 30", "Wire (30)" },
                    { "assess 11", "Wire (11)" },
                    { "assess instr", "Instr" },
                    { "assess 1512", "1512" },
                    { "assess RA1", "RA1" },
                    { "assess 230", "230" },
                    { "assess 20", "Wire (20)" },
                    { "assess 39", "Wire (39)" },
                    { "assess 43", "Wire (43)" },
                    { "assess 46", "Wire (46)" },
                    { "assess ALUControl", "ALUControl" },
                };
            }
        }

        else if (instr_type == typeof(Str)) {
            active_objects = new Dictionary<string, string> {
                { "CLK to IM assess", "CLK to IM" },
                { "assess 11", "Wire (11)" },
                { "assess instr", "Instr" }, 
                { "assess RA1", "RA1" },
                { "assess RA2", "RA2" },
                { "assess 230", "230" },
                { "assess 20", "Wire (20)" },
                { "assess 38", "Wire (38)" },
                { "assess 45", "Wire (45)" },
                { "assess 39", "Wire (39)" },
                { "assess 43", "Wire (43)" },
                { "assess ALUControl", "ALUControl" },
            };
        }

        else if (instr_type == typeof(Ldr)) {
            active_objects = new Dictionary<string, string> {
                { "CLK to IM assess", "CLK to IM" },
                { "assess 30", "Wire (30)" },
                { "assess 11", "Wire (11)" },
                { "assess instr", "Instr" },
                { "assess 1512", "1512" },
                { "assess RA1", "RA1" },
                { "assess 230", "230" },
                { "assess 20", "Wire (20)" },
                { "assess 45", "Wire (45)" },
                { "assess 39", "Wire (39)" },
                { "assess 43", "Wire (43)" },
                { "assess 48", "Wire (48)" },
                { "assess ALUControl", "ALUControl" },
            };
        }

        // Iterate through each assessment object and check against UI object to see if it's correct.
        foreach (KeyValuePair<string, string> kvp in active_objects) {
            var wire = GameObject.Find(kvp.Value);
            var sphere_text = Util.FindObject(wire, "Text").GetComponent<Text>().text.ToUpper();
            var assess_text = Util.FindObject(assessment_input, kvp.Key).GetComponent<InputField>().text.ToUpper();

            if (assess_text != sphere_text) {
                var text_field = Util.FindObject(assessment_input, kvp.Key);
                // Set color of text in textfield red.
                Util.FindObject(text_field, "Text").GetComponent<Text>().color = Color.red;
                // Set color of wire red.
                wire.GetComponent<SelectWire>().changeColor("red");

                correct_input = false;
            }
            else {
                // Reset colors.
                var assess = Util.FindObject(assessment_input, kvp.Key);
                wire.GetComponent<SelectWire>().changeColor("yellow");
                Util.FindObject(assess, "Text").GetComponent<Text>().color = Color.black;
            }
        }

        // Checks for extra wires that were selected but are not correct.
        foreach (Transform child in assessment_input.transform) {
            // If there is an active input object that is not in the predefined dictionary,
            //   the user selected something incorrect.
            if (child.gameObject.activeSelf) {
                string val = null;
                active_objects.TryGetValue(child.gameObject.name, out val);

                if (val == null)
                    return false;
            }
        }

        return correct_input; 
    }

    public Instruction get_currentOperation(){
        return currentOperation;
    }
}


