using UnityEngine;
using UnityEngine.UI;

public abstract class Instruction {
    protected bool done = false;

    protected string operation;
    protected string rd;
    protected string rs;
    protected string rt;
    protected string imm;
    protected GameObject container;

    protected bool has_imm;

    protected bool firstset = true;
    protected float timefactor = 1f;

    public Instruction(string rd, string rs, string rt, string imm, GameObject container) {
        this.done = false;
        this.rd = rd;
        this.rs = rs;
        this.rt = rt;
        this.imm = imm; //cast nullable int to int
        this.container = container;

        if (imm == null) has_imm = false;
        else has_imm = true;
    }
    
    public void container_on() {
        if(firstset) {
            container.GetComponent<Image>().enabled = true;
            container.GetComponent<Image>().color = new Color32(17,207,31,248);
            firstset = false;
        }
    }
    
    public void container_off() {
        container.GetComponent<Image>().enabled = false;
        firstset = true;
    }
    
    public bool isdone() {
        return done;
    }
    
    public void time_setter(float factor) {
        this.timefactor = factor;
    }
    
    public void timeController() {
        Time.timeScale = timefactor;
    }
    
    public void set_done(bool val) {
        done = val;
    }

    public string tohex(string hex) {
        string h = "0x";
        for (int i = 0; i < 8 - hex.Length; i++) {
            h += "0";
        }
        return h + hex;
    }

    public abstract void operate();
    
    public abstract bool get_has_imm();
    
    public abstract string get_Name();
}
