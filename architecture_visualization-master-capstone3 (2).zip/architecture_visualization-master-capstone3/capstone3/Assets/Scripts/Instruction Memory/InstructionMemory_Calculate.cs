using System.Collections.Generic;
using UnityEngine;

public class InstructionMemory_Calculate : MonoBehaviour {
    public GameObject CLK_to_IM;
    public Dictionary<string, Instruction> I_Memory = new Dictionary<string, Instruction>();
    private bool done = false;
    
    public void calculate() {
        if(CLK_to_IM.GetComponent<CLK_SphereController>().isdone())
            done = true;
        
    }

    public void set_addr_operation(string addr, Instruction op) {
        I_Memory[addr] = op;
    }

    public bool isdone() {
        return this.done;
    }
    
    public void reset() {
        this.done = false;
    }
}
