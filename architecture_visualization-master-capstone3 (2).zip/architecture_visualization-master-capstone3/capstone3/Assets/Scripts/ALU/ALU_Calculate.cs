using UnityEngine;

public class ALU_Calculate : MonoBehaviour {
    public GameObject W20;
    public GameObject W39;
    public GameObject W62;
    
    private bool done = false;
    
    public void calculate(bool mov){
        if (W20.transform.GetChild(0).GetComponent<W20_SphereController>().isdone() &&
            W62.GetComponent<W62_SphereController>().isdone() &&
            W39.transform.GetChild(0).GetComponent<W39_SphereController>().isdone()) {

            done = true;
        }

        if (mov) {
            if (W20.transform.GetChild(0).GetComponent<W20_SphereController>().isdone() ||
                W39.transform.GetChild(0).GetComponent<W39_SphereController>().isdone()) {

                done = true;
            }
        }
    }
    
    public bool isdone() {
        return this.done;
    }
    
    public void reset() {
        this.done = false;
    }
}
