using UnityEngine;

public class MuxSrcb_Calculate : MonoBehaviour {
    public GameObject W38;
    public GameObject W40;
    
    private Instruction currentOperation;
    private bool first_calculate = true;
    private bool done = false;
    
    public void calculate(){
        if(first_calculate) {
            currentOperation = GameObject.Find("CLK").GetComponent<Run>().get_currentOperation();
            first_calculate = false;
        }
        if((W38.transform.GetChild(0).GetComponent<W38_SphereController>().isdone() && !currentOperation.get_has_imm()) 
            || 
            W40.transform.GetChild(0).GetComponent<W40_SphereController>().isdone()) {

            done = true;
        }
    }
    
    public bool isdone() {
        return this.done;
    }
    
    public void reset() {
        this.first_calculate = true;
        this.done = false;
    }
}
