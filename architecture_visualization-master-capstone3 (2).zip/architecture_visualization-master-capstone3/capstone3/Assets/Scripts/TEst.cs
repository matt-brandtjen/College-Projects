using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TEst : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        //Debug.Log(1000.ToString("X"));
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
