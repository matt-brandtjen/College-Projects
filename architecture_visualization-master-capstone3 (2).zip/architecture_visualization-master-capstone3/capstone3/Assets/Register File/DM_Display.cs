﻿using UnityEngine;
using UnityEngine.UI;

public class DM_Display : MonoBehaviour {
    public GameObject input_addr;
    public GameObject input_val;
    public GameObject DM;
    public GameObject display_dm;

    private string addr_txt;
    private string input_val_txt;

    public void setData() {
        addr_txt = input_addr.GetComponent<InputField>().text;
        input_val_txt = input_val.GetComponent<InputField>().text;

        // Set Data Memory.
        DM.GetComponent<DataMemory_Calculate>().set_mem_util(addr_txt, input_val_txt);

        // reset value in textfield
        input_val.GetComponent<InputField>().text = "";
        input_addr.GetComponent<InputField>().text = "";
    }

    void Update() {
        string a = DM.GetComponent<DataMemory_Calculate>().print_data();
        display_dm.GetComponent<Text>().text = a;
    }

}

