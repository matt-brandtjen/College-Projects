using System.Collections.Generic;
using UnityEngine;

public class RegisterFile : MonoBehaviour
{

    public GameObject RA1; // top wire into RF
    public GameObject RA2; // second wire into RF
    public GameObject W1512; // third wire into RF
    
    public Dictionary<string, string> R_file = new Dictionary<string, string>(); // underlying representation of register file
    /*
     * This is an example of what the the Dictionary would look like if all registers held value zero
     * 
    {
        {"R0", 0},
        {"R1", 0},
        {"R2", 0},
        {"R3", 0},
        {"R4", 0},
        {"R5", 0},
        {"R6", 0},
        {"R7", 0},
        {"R8", 0},
        {"R9", 0},
        {"R10", 0},
        {"R11", 0},
        {"R12", 0},
        {"R13", 0},
        {"R14", 0},
        {"R15", 0},
    };*/


    private Instruction currentOperation;

    private bool done = false;
    private bool first_calculate = true;


    public void set_Register(string register, string value)
    {
        R_file[register.ToUpper()] = value;
    }
    
    public bool ContainsR(string register)
    {
        return R_file.ContainsKey(register.ToUpper());
    }
    
    public void set_Ra_equal_Rb(string register1, string register2)
    {
        R_file[register1.ToUpper()] = R_file[register2.ToUpper()];
    }


    public string get_RegisterVal(string register)
    {
        if( R_file.ContainsKey( register.ToUpper() ) )
        {
            return R_file[register.ToUpper()];
        }
        else
        {
            return "0";
        }
    }
    
    public void calculate(){
        
        if(first_calculate){
            currentOperation = GameObject.Find("CLK").GetComponent<Run>().get_currentOperation();
            first_calculate = false;
        }
        if((RA1.GetComponent<RA1_SphereController>().isdone() &&
            RA2.GetComponent<RA2_SphereController>().isdone() &&
            W1512.GetComponent<SphereController1512>().isdone())
            ||
            (currentOperation.get_has_imm() &&
            RA1.GetComponent<RA1_SphereController>().isdone() &&
            W1512.GetComponent<SphereController1512>().isdone() &&
            !currentOperation.get_Name().Contains("str"))
            ||
            (RA1.GetComponent<RA1_SphereController>().isdone() &&
            RA2.GetComponent<RA2_SphereController>().isdone() &&
            currentOperation.get_Name().Contains("str"))
            ||
            (RA1.GetComponent<RA1_SphereController>().isdone() &&
            RA2.GetComponent<RA2_SphereController>().isdone() &&
            currentOperation.get_Name().Contains("beq"))
            ||
            (RA1.GetComponent<RA1_SphereController>().isdone() &&
            W1512.GetComponent<SphereController1512>().isdone() &&
            currentOperation.get_Name().Contains("ldr"))
            ||
            (RA1.GetComponent<RA1_SphereController>().isdone() &&
            W1512.GetComponent<SphereController1512>().isdone() &&
            currentOperation.get_Name().Contains("mov"))
            )
            {
            done = true;
        }
    }
    
    public bool isdone(){
        return done;
    }
    
    public void reset(){
        this.done = false;
        this.first_calculate = true;
    }

    public string print_dic()
    {
        string a = "";
        string b = "";
        foreach (KeyValuePair<string, string> kvp in R_file)
        {
            if (kvp.Key != "R15")
            {
                a = kvp.Key + " : " + kvp.Value + "\n";
                b += a; 
            }  
        }

        return b;
    }
}
