using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class RF_Display : MonoBehaviour {
    public Transform dropdownMenu;
    public GameObject input_num;
    public GameObject display_rf;
    public GameObject RF;

    private string num_txt;

    public void setData() {
        // get textfield input value as string
        num_txt = input_num.GetComponent<InputField>().text;

        // get index of register dropdown value
        int menuIndex = dropdownMenu.GetComponent<Dropdown>().value;

        // get list of values in register dropdown
        List<Dropdown.OptionData> menuOptions = dropdownMenu.GetComponent<Dropdown>().options;

        // get target register value as string
        string register = menuOptions[menuIndex].text;

        // set target register value in RegisterFile
        RF.GetComponent<RegisterFile>().set_Register(register, num_txt);

        // reset value in textfield
        input_num.GetComponent<InputField>().text = "";
    }
    
    void Update() {
        
        string a = RF.GetComponent<RegisterFile>().print_dic();
        display_rf.GetComponent<Text>().text = a;
    }
}

