package model;
public class Timing {
    long startTime;
    long endTime;

    public void start() {
        startTime = System.currentTimeMillis();
    }

    public void end() {
        endTime = System.currentTimeMillis();
    }

    public String toString() {
        long totalMilliSeconds = (endTime - startTime);
        long totalSeconds = totalMilliSeconds / 1000;
        long currentSecond = totalSeconds % 60;

        //求出现在的秒


        return (String.valueOf(currentSecond));
    }

}