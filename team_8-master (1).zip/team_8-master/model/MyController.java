package model;



import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class MyController implements ActionListener {

    private ArrayList<Card> faceUpCards;
    private int correct;
    private boolean end=false;


    public MyController(int x){
        this.faceUpCards=new ArrayList<>(2);
        this.correct=x;
    }

    public boolean faceUp (Card card){
        if(this.faceUpCards.size()<2){
            return doAddCard(card);
        }
        return false;
    }
    public boolean check(){
        if (correct == 0){
            end=true;
            return true;
        }
        return false;
    }

    public boolean doAddCard (Card card){
        this.faceUpCards.add(card);
        if(this.faceUpCards.size()==2){
            Card other=this.faceUpCards.get(0);
            if(other.getNum()==card.getNum()){
                this.faceUpCards.clear();
                correct=correct-1;
                check();
            }
            else{
                try{
                    Thread.sleep(1000);
                }catch(Exception e){
                    e.printStackTrace();
                }
                card.turnback();
                other.turnback();
                this.faceUpCards.clear();
            }
        }
        return true;
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        for (int i=0;i<this.faceUpCards.size();i++){
            Card card=(Card)this.faceUpCards.get(i);
            card.turnback();
        }
        this.faceUpCards.clear();
    }
    public boolean getEnd(){
        return end;
    }
}
