package model;


import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

public class Card extends JLabel implements MouseListener{

    private MyController controller;
    Icon icon;
    JLabel I;
    String picaddress;
    boolean up=false;
    boolean pressed=false;
    int num;
    JLabel pic;
    Icon icon2;
    JLabel II;
    JButton reverse;
    int halfw;
    int halfh;




    public Card(MyController controller,String address,int num) {
        this.num=num;

        I = new JLabel();
        //mainPanel.setPreferredSize(new Dimension(100, 300));
        icon = new ImageIcon(address);
        I.setIcon(icon);
        I.setSize(70,120);


        JButton reverse = new JButton();
        II = new JLabel();
        //mainPanel.setPreferredSize(new Dimension(100, 300));
        icon2 = new ImageIcon("image/timg.jpg");
        II.setIcon(icon2);
        II.setSize(icon.getIconWidth(), icon.getIconHeight());
        reverse.add(II, new Integer(Integer.MIN_VALUE));

        this.setIcon(icon2);
        this.addMouseListener(this);
        this.halfh=icon.getIconHeight()/2;
        this.halfw=icon.getIconWidth()/2;

        this.controller=controller;
        this.num=num;

    }


    public int getNum(){return num;}




    public JLabel getPic()
    {
        return pic;
    }
    public void setPic(JLabel I)
    {
        this.pic=I;
    }
    public String getAddress()
    {
        return picaddress;
    }
    public void setAddress(String address)
    {
        this.picaddress=address;
    }

    public JButton getReverse()
    {
        return reverse;
    }
    public void setReverse(JButton reverse)
    {
        this.reverse=reverse;
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        this.turn();
    }
    public void turn(){
        if (this.up) {
            return;
        }
        this.up=true;
        if (this.up){
            this.setIcon(icon);
        }
        this.controller.faceUp(this);

    }
    public void turnback(){
        if (!this.up) {
            return;
        }
        this.setIcon(icon2);
        this.up=false;
    }
    @Override
    public void mousePressed(MouseEvent e) {
        this.mouseClicked(e);
    }

    @Override
    public void mouseReleased(MouseEvent e) {
    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {
    }
}


