import static org.junit.Assert.*;
import org.junit.*;

public class PlayerTest
{
    public static void setNameTest(String expectedName) {
        Player p = new Player();
        p.name = expectedName;
        String actualName = p.setName();
        assertEquals("p.setName()", expectedName, actualName);
    }

    @Test
    public void testSetName() {
        setNameTest("Metta");
    }

    public static void getNameTest(String expectedName)
    {
        Player p = new Player();
        p.name = expectedName;
        String actualName = p.getName();
        assertEquals("p.getName()", expectedName, actualName);
    }

    @Test
    public void testGetName() {
        getNameTest("Metta");
    }

    public static void setLevelTest(String expectedLevel)
    {
        Player p = new Player();
        p.level = expectedLevel;
        String actualLevel = p.setLevel();
        assertEquals("p.setLevel()", expectedLevel, actualLevel);
    }

    @Test
    public void testSetLevel()
    {
        setLevelTest("EASY");
    }

    @Test
    public void testGetScore()
    {
        
    }


}