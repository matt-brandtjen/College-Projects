package model;

public class Player {

    private String name;
    private int level;
    private int Score;


    public void setName(String nm) {
        this.name = nm;
    }

    public String getName() {
        return this.name;
    }

    public void setLevel (int lvl) {
        this.level = lvl;
    }

    public int getLevel() {
        return this.level;
    }

    public void setScore(int x){
        this.Score=x;
    }
    public int getScore(){
        return Score;
    }


}
