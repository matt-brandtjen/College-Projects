package ui;
import model.*;


import java.io.*;
import java.util.ArrayList;
import java.util.List;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.lang.*;
import java.util.Collections;

import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

public class Game extends JFrame{
    private JFrame gameFrame = new JFrame("Level 1");
    public String currentCard;
    public String secondCard;
    public int correct;
    public int hit=2;
    public JLabel picture;
    public JLabel picture2;
    public ArrayList<String> addr=new ArrayList<String>();
    public int level;
    private String icon[];
    private MyController controller;
    private String score;
    public JLabel Score;
    public JButton Exit;
    public Boolean leave=false;
    public JLabel level1;
    public JLabel timer;
    public Timing time;
    public Player player;

    public Game(Player player) {
        this.player=player;

        this.level=player.getLevel();

        gameFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        gameFrame.setPreferredSize(new Dimension(1500, 800));
        gameFrame.setLayout(null);
        Font f1 = new Font("Times New Roman", Font.PLAIN, 80);
        level1 = new JLabel("Level" + level);
        level1.setFont(f1);
        level1.setForeground(Color.PINK);
        timer = new JLabel();
        gameFrame.add(timer);
        gameFrame.add(level1);
        level1.setBounds(450, 0, 300, 100);
        this.icon = loadImage();


        Exit = new JButton("Exit");
        Exit.setFont(f1);
        Exit.setForeground(Color.PINK);
        Exit.setBounds(1200,0,300,50);
        gameFrame.add(Exit);

        Exit.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                leave=true;
                gameFrame.setVisible(false);
            }
        });








        //当全部做完时，游戏结束
    }

    //虽然提取出了matching但是发现仍然需要对Level1内的数据进行操作，暂时有主意将其拉出

    private String[] loadImage() {
        String icon[]=new String[15];
        for (int j=0; j<15;j++){
            String filename="image/"+j+".png";
            icon[j]=filename;
        }
        return icon;
    }

    public JPanel makeCard(int x){
        JPanel panel = new JPanel();
        if (x==1){
            correct=6;
            ArrayList<Card> container=new ArrayList<>();
            panel=new JPanel(new GridLayout(2,6));
            panel.setSize(1500,700);
            controller=new MyController(6);
            for (int i =0;i<6;i++){
                Card newCard=new Card(controller,icon[i],i);
                container.add(newCard);
            }
            for (int i =0;i<6;i++){
                Card newCard=new Card(controller,icon[i],i);
                container.add(newCard);
            }
            Collections.shuffle(container);
            for (int i=0;i<container.size();i++){
                panel.add(container.get(i));
            }
        }

        if (x==2){
            correct=10;
            ArrayList<Card> container=new ArrayList<>();
            panel=new JPanel(new GridLayout(2,10));
            panel.setSize(1500,700);
            controller=new MyController(10);
            for (int i =0;i<10;i++){
                Card newCard=new Card(controller,icon[i],i);
                container.add(newCard);
            }
            for (int i =0;i<10;i++){
                Card newCard=new Card(controller,icon[i],i);
                container.add(newCard);
            }
            Collections.shuffle(container);
            for (int i=0;i<container.size();i++){
                panel.add(container.get(i));
            }
        }

        if (x==3){
            correct=15;
            ArrayList<Card> container=new ArrayList<>();
            panel=new JPanel(new GridLayout(3,10));
            panel.setSize(1500,700);
            controller=new MyController(15);
            for (int i=0; i<15;i++){
                Card newCard=new Card(controller,icon[i],i);
                container.add(newCard);
            }
            for (int i=0; i<15;i++){
                Card newCard=new Card(controller,icon[i],i);
                container.add(newCard);
            }
            Collections.shuffle(container);
            for (int i=0;i<container.size();i++){
                panel.add(container.get(i));
            }
        }
        return panel;
    }
    public void gameStart(int x) {
        this.icon = loadImage();
        JPanel p = makeCard(x);

        this.gameFrame.setSize(1500,800);
        this.gameFrame.add(p);
        p.setLocation(0, 100);



        time= new Timing();
        time.start();
        final long timeInterval = 1000;
        Runnable runnable = new Runnable() {
            public void run() {
                boolean con=true;
                while (con=true) {
                    controller.check();
                    time.end();
                    score = time.toString();
                    timer.setText("Current time  " + score + "  second");
                    Font f2 = new Font("Times New Roman", Font.PLAIN, 20);
                    timer.setForeground(Color.PINK);
                    timer.setFont(f2);
                    timer.setBounds(0,0,500,100);
                    if (controller.getEnd() == true){
                        gameFrame.remove(timer);
                        level1.setFont(f2);
                        level1.setBounds(0,0,1500,100);
                        score = time.toString();
                        level1.setText("Your Score is "+ score+" second, please click Exit.");
                        player.setScore(Integer.valueOf(score));
                        ArrayList<String> LL1=new ArrayList<>();
                        try (FileReader reader = new FileReader("score/level"+player.getLevel()+".txt");
                             BufferedReader br = new BufferedReader(reader)
                        ) {
                            String line;
                            while ((line = br.readLine()) != null) {
                                String[] matched_np_id=line.split(":");
                                for (int i=0;i<matched_np_id.length;i++) {
                                    LL1.add(matched_np_id[i]);
                                }
                            }}
                        catch (IOException e) {
                            e.printStackTrace();
                        }
                        if(Integer.valueOf(LL1.get(2))>Integer.valueOf(score)){
                            try {
                                File record = new File("score/level"+player.getLevel()+".txt");
                                record.createNewFile();
                                try (FileWriter writer  = new FileWriter("score/level"+player.getLevel()+".txt");
                                     BufferedWriter out = new BufferedWriter(writer)
                                ) {
                                    out.write(player.getName()+":"+player.getLevel()+":"+player.getScore());
                                    out.flush();
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }
                            }
                            catch (IOException e) {
                                e.printStackTrace();
                            }
                        }
                        break;
                    }
                    try {
                        // sleep()：同步延迟数据，并且会阻塞线程
                        Thread.sleep(timeInterval);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        };
        //创建定时器
        Thread thread = new Thread(runnable);
        //开始执行
        thread.start();

        this.gameFrame.setVisible(true);

    }

    public Boolean getLeave() {
        return leave;
    }



}
/**
 public void setLevel(Level level)
 {
 puzzle=new Puzzle(level);
 gameBoard=new Board(puzzle,this);
 gameBoard.initialize();
 }
 private Game game;
 private Player player;
 pribate Level currentDifficultyl
 public StartManu(Game game,Player player){
 }
 private class LevelButton extend JButton implements ActionListener{
 private Level level;
 public LevelButton(Level 1, Player p){

 }
 public void actionPerformed(ActionEvent event){
 //set the difficulty level
 game.setLevel(level);
 }
 public class Board extends JPanel{
 private JButton[] tiles;
 private int size;
 }
 Puzzle implements Iterable<integer>;
 puzzle has;

 public void playerMoved();

 private class ButtonListener implements ActionListener{
 }

 difficulty level, solution 1 make blockfactory aware of teh difficulty level
 solution 2 have multiple factories

 */