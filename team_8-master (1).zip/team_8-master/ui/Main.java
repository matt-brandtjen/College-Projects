package ui;
import model.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

import java.util.ArrayList;
import java.util.List;
import java.io.*;
import java.util.Timer;
import java.util.TimerTask;

public class Main {
    private static Game game;
    public JFrame mainFrame;

    public static void main(String[] args){

        ArrayList<String> level1 = new ArrayList();
        ArrayList<String> level2 = new ArrayList();
        ArrayList<String> level3 = new ArrayList();
        try {
            File ff1 = new File("score/level1.txt");
            File ff2 = new File("score/level2.txt");
            File ff3 = new File("score/level3.txt");
        }catch (Exception e) {
            e.printStackTrace();
        }
        try (FileReader reader = new FileReader("score/level1.txt");
             BufferedReader br = new BufferedReader(reader) // 建立一个对象，它把文件内容转成计算机能读懂的语言
        ) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] matched_np_id=line.split(":");
                level1=new ArrayList<>();
                for (int i=0;i<matched_np_id.length;i++) {
                    level1.add(matched_np_id[i]);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        try (FileReader reader = new FileReader("score/level2.txt");
             BufferedReader br = new BufferedReader(reader) // 建立一个对象，它把文件内容转成计算机能读懂的语言
        ) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] matched_np_id=line.split(":");
                level2=new ArrayList<>();
                for (int i=0;i<matched_np_id.length;i++) {
                    level2.add(matched_np_id[i]);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        try (FileReader reader = new FileReader("score/level3.txt");
             BufferedReader br = new BufferedReader(reader) // 建立一个对象，它把文件内容转成计算机能读懂的语言
        ) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] matched_np_id=line.split(":");
                level3=new ArrayList<>();
                for (int i=0;i<matched_np_id.length;i++) {
                    level3.add(matched_np_id[i]);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }



        JFrame mainFrame = new JFrame("main manu");
        mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        mainFrame.setPreferredSize(new Dimension(1200,800));
        mainFrame.setLayout(null);
        Font font = new Font("Times New Roman", Font.PLAIN, 80);
        JLabel title = new JLabel("JOJO Card");
        title.setFont(font);
        title.setForeground(Color.PINK);
        // how to set the text size
        mainFrame.add(title);
        title.setBounds(400,100,1000,200);

        JPanel mainPanel = new JPanel();
        mainPanel.setPreferredSize(new Dimension(1200, 800));

        JButton submitButton = new JButton("Submit");
        JLabel label = new JLabel();
        label.setText("Please Enter Your Name:");
        Font f = new Font("Times New Roman", Font.PLAIN,24);
        label.setFont(f);
        label.setForeground(Color.BLUE);
        label.setBounds(350,300,300,30);
        mainFrame.add(label);

        JTextField answerField = new JTextField();
        answerField.setBounds(600,300,200, 30);
        mainFrame.add(answerField);

        answerField.getText().equals(null);


        mainFrame.add(label);


        JButton L1 = new JButton("Level 1");
        L1.setBounds(100,400,300,50);
        Font f1 = new Font("Times New Roman", Font.PLAIN, 14);
        String p1 = new String();
        p1=level1.get(0)+" "+level1.get(2)+" second";
        JLabel s1 = new JLabel("Highest Score " + p1);
        s1.setFont(f1);
        s1.setForeground(Color.RED);
        mainFrame.add(s1);
        s1.setBounds(100,500,300,50);
        L1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if(answerField.getText().equals(null)){
                    return;
                }
                else{
                    Player player;
                    player=new Player();
                    player.setLevel(1);
                    player.setName(answerField.getText());
                    game=new Game(player);
                    game.gameStart(player.getLevel());
                }
            }
        });

        JButton L2 = new JButton("Level 2");
        L2.setBounds(450,400,300,50);
        String p2 = new String();
        p2=level2.get(0)+" "+level2.get(2)+" second";
        JLabel s2 = new JLabel("Highest Score " + p2);
        s2.setFont(f1);
        s2.setForeground(Color.RED);
        mainFrame.add(s2);
        s2.setBounds(450,500,300,50);
        L2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if(answerField.getText().equals(null)){
                    return;
                }
                else{
                    Player player;
                    player=new Player();
                    player.setLevel(2);
                    player.setName(answerField.getText());
                    game=new Game(player);
                    game.gameStart(player.getLevel());
                }

            }
        });

        JButton L3 = new JButton("Level 3");
        L3.setBounds(800,400,300,50);
        String p3 = new String();
        p3=level3.get(0)+" "+level3.get(2)+" second";
        JLabel s3 = new JLabel("Highest Score "+ p3);
        s3.setFont(f1);
        s3.setForeground(Color.RED);
        mainFrame.add(s3);
        s3.setBounds(800,500,300,50);
        L3.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if(answerField.getText().equals(null)){

                }
                else{
                    Player player;
                    player=new Player();
                    player.setLevel(3);
                    player.setName(answerField.getText());
                    game=new Game(player);
                    game.gameStart(player.getLevel());
                }
            }
        });



        JButton exit = new JButton("Exit");
        exit.setBounds(450,700,300,50);
        exit.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                System.exit(1);
            }
        });
        mainFrame.add(L1);
        mainFrame.add(L2);
        mainFrame.add(L3);
        mainFrame.add(exit);



        mainFrame.add(mainPanel);
        mainPanel.setLocation(1200,400);
        mainFrame.pack();
        mainFrame.setVisible(true);


        // write your code here

    }


}
