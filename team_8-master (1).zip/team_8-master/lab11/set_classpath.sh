CLASSPATH=$CLASSPATH:/usr/share/java/junit.jar:.
alias junit="java -cp $CLASSPATH org.junit.runner.JUnitCore"
