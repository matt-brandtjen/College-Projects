/*
 * Game level
 */

public enum Level
{
    EASY, MEDIUM, HARD;
}
